//
//  Backpack.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//this is the backpack class, which is a container of items which has a weight limit so that the player can only hold up to a certain amount
class Backpack : Item {
    var container : [String : Item]
    var weightLimit : float_t
    var currentHolding : float_t 
    var underMaxWeight : Bool?
    
    init(name : String, weight : float_t, value : integer_t, limit : float_t) {
        container = [String : Item]()
        weightLimit = limit
        self.currentHolding = 0.0
        super.init(name: name, weight: weight, value: value)
    }
    //sets weightlimit
    func setWeightLimit(_ weightLimit : float_t) {
        self.weightLimit = weightLimit
    }
    
    override func isBackpack() -> Bool {
        return true
    }
    //allows to find item in backpack without removing it
    func peekItem(_ itemName : String) -> Item? {
        return container[itemName]
    }
    //increases weight limit of backpack
    func increaseLimit(_ amount : float_t) {
        setWeightLimit(getWeightLimit() + amount)
    }
    
    //removes items from backpack
    func removeItems() -> [String : Item]? {
        if isEmpty() == false {
            let temp : [String : Item]? = container
            container.removeAll()
            return temp
        } else {
            return nil
        }
    }
    //stores item in backpack
    func store(_ item : Item) {
        container[item.name] = item
        currentHolding += item.getWeight()
    }
    //retrieves item from backpack
    func retrieve(_ itemName : String) -> Item? {
        
        if container.isEmpty == true {
            return nil
        } else {
            let thisItem : Item? = container.removeValue(forKey: itemName)
            if thisItem != nil {
                
                currentHolding -= thisItem!.getWeight()               
                
                return thisItem
            } else {
                return nil
            }
            
        }        
    }
    //checks if backpack is empty
    func isEmpty() -> Bool {
        return container.isEmpty
    }
    //gets weight limit of backpack
    func getWeightLimit() -> float_t {
        return weightLimit
    }
    //check if backpack can hold an item
    func canHold(_ item : Item) -> Bool {
        if (currentHolding + item.getWeight()) < getWeightLimit() {
            underMaxWeight = true
        } else {
            underMaxWeight = false
        }
        return underMaxWeight!
    }
    //checks if backpack has this specific item
    func hasThisItem(_ itemName : String) -> Bool {
        if isEmpty() == false {
            if (container[itemName]) != nil {
                return true
            } else {
                return false
            }
        } else {
            return false
        }
    }
    
    //gets total value of all items in the backpack
    override func getValue() -> integer_t {
        var totalValue : integer_t = 0
        for item in container.values {
            totalValue += item.getValue()
        }
        totalValue += super.getValue()
        return totalValue
    }
    //gets total weight of all items in the backpack
    override func getWeight() -> float_t {
        var totalWeight : float_t = 0.0
        for item in container.values {
            totalWeight += item.getWeight()
        }
        totalWeight += super.getWeight()
        return totalWeight
    }
    //gets list of items in backpack
    func getList() -> String {
        var listing : String = "\(name) contains \n"
        
        for item in container.values {
            listing += "\n * \(item.description())"
        }
        return listing
    }
    //specifically gets list of items in backpack, formatted for output message
    func npcListing() -> String {
        var listing : String = ""
        
        for item in container.values {
            listing += "\n * \(item.description())"
        }
        return listing
    }
    
}
