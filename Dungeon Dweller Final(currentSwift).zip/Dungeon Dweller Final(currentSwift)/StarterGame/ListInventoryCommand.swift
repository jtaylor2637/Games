//
//  ListInventoryCommand.swift
//  StarterGame
//
//  Created by csu on 4/25/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//lists items the player is holding, if they type inventory
class ListInventoryCommand : Command {
    override init() {
        super.init()
        self.name = "inventory"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasSecondWord() {
            player.warningMessage("\nTo list your inventory just type inventory")
        } else {
            player.listItems()
        }
        return false
    }
}
