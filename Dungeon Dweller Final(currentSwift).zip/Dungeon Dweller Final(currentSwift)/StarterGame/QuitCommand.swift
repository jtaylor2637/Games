//
//  QuitCommand.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// quit commmand which allows the player to end the game at any time because they were so bad at the game they had to quit
class QuitCommand: Command {
    
    override init() {
        super.init()
        self.name = "quit"
    }
    //sets playing to false to end game
    override func execute(_ player: Player) -> Bool {
        var answer : Bool = true
        if hasSecondWord() {
            player.warningMessage("\nI cannot quit \(secondWord)")
            answer = false
        }
        return answer
    }
}
