//
//  StatsCommand.swift
//  StarterGame
//
//  Created by csu on 4/27/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// this displays the player's stats when player types stats
class StatsCommand: Command {
    
    override init() {
        super.init()
        self.name = "stats"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasSecondWord() {
            player.warningMessage("\nThis is a one word command")
        } else {
            player.getStats()   
        }
        return false
    }
}
