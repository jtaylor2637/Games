//
//  Lockables.swift
//  StarterGame
//
//  Created by csu on 4/21/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation



// lockables which are used to create locks for doors
class RegularLock : Lockable {
    var lockedState : Bool = false
    var originalKey : Item?
    var insertedKey : Item?
    
    /*init() {
        originalKey = Item(name: "regularKey")
        insertedKey = originalKey
    }*/
    
    func setOriginalKey(_ item : Item) {
        originalKey = item
    }
    
    func setInsertedKey() {
        insertedKey = originalKey
    }
    
    
    func lock() {
        lockedState = true
    }
    
    func unlock() {
        lockedState = false
    }
    
    func isLocked() -> Bool {
        return lockedState
    }
    
    func canClose() -> Bool {
        return true
    }
    
    func canRegularPick() -> Bool {
        return true
    }
    
    func canMagicPick() -> Bool {
        return true
    }
    
    func canMakeShiftPick() -> Bool {
        return false
    }
    
    func insertKey(_ key : Item) -> Bool {
        if insertedKey == nil {
            insertedKey = key
            return true
        } else {
            return false
        }
    }
    
    func removeKey() -> Item? {
        let tempKey : Item? = insertedKey
        insertedKey = nil
        return tempKey
    }
    
    func getOriginalKey() -> Item? {
        return originalKey
    }

}

class DeadBolt : Lockable {
    
    var lockedState : Bool = false
    var originalKey : Item?
    var insertedKey : Item?
    
    /*init() {
        originalKey = Item(name: "deadboltKey")
        insertedKey = originalKey
    }*/
    func setOriginalKey(_ item : Item) {
        originalKey = item
    }
    
    func setInsertedKey() {
        insertedKey = originalKey
    }
    
    func lock() {
        lockedState = true
    }
    func unlock() {
        lockedState = false
    }
    
    func isLocked() -> Bool {
        return lockedState
    }
    
    func canClose() -> Bool {
        if isLocked() == true {
            return true
        } else {
            return false
        }
        
    }
    
    func canRegularPick() -> Bool {
        return true
    }
    
    func canMagicPick() -> Bool {
        return true
    }
    
    func canMakeShiftPick() -> Bool {
        return true
    }
    
    func insertKey(_ key : Item) -> Bool {
        if insertedKey == nil {
            insertedKey = key
            return true
        } else {
            return false
        }
    }
    
    func removeKey() -> Item? {
        let tempKey : Item? = insertedKey
        insertedKey = nil
        return tempKey
    }
    
    func getOriginalKey() -> Item? {
        return originalKey
    }

}


class CellLock : Lockable {
    
    var lockedState : Bool = false
    var originalKey : Item?
    var insertedKey : Item?
    
    /*init() {
        originalKey = Item(name: "cellKey")
        insertedKey = originalKey
    }*/

    
    func setOriginalKey(_ item : Item) {
        originalKey = item
    }
    
    func setInsertedKey() {
        insertedKey = originalKey
    }
    
    
    
    func lock() {
        lockedState = true
    }
    func unlock() {
        lockedState = false
    }
    
    func isLocked() -> Bool {
        return lockedState
    }
    
    func canClose() -> Bool {
        return true
    }
    
    func canRegularPick() -> Bool {
        return true
    }
    
    func canMagicPick() -> Bool {
        return true
    }
    
    func canMakeShiftPick() -> Bool {
        return true
    }
    
    func insertKey(_ key : Item) -> Bool {
        if insertedKey == nil {
            insertedKey = key
            return true
        } else {
            return false
        }
    }
    
    func removeKey() -> Item? {
        let tempKey : Item? = insertedKey
        insertedKey = nil
        return tempKey
    }
    
    func getOriginalKey() -> Item? {
        return originalKey
    }


}
