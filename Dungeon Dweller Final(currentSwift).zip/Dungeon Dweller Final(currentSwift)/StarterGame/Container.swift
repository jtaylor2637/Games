//
//  Container.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//unused but can be used to store items into chests or other containers if we needed to populate rooms with such containers
class Container : Item {
    var container : [String : Item]
    
    override init(name : String, weight : float_t, value : integer_t) {
        container = [String : Item]()
        super.init(name: name, weight: weight, value: value)
    }
    
    override func isContainer() -> Bool {
        return true
    }
    
    func store(_ item : Item) {
        container[item.name] = item
    }
    
    func retrieve(_ itemName : String) -> Item? {
        return container.removeValue(forKey: itemName)
    }
    
    override func getValue() -> integer_t {
        var totalValue : integer_t = 0
        for item in container.values {
            totalValue += item.getValue()
        }
        totalValue += super.getValue()
        return totalValue
    }
    
    override func getWeight() -> float_t {
        var totalWeight : float_t = 0.0
        for item in container.values {
            totalWeight += item.getWeight()
        }
        totalWeight += super.getWeight()
        return totalWeight
    }
    
    func getList() -> String {
        var listing : String = "\(name) contains \n"
        
        for item in container.values {
            listing += "\n * \(item.description())"
        }
        return listing
    }
    
    
}
