//
//  OpenCommand.swift
//  StarterGame
//
//  Created by csu on 4/21/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//allows the player to open doors and other items if there were other items to open in the game, the correct use of this command is open door (direction)
class OpenCommand: Command {
    
    override init() {
        super.init()
        self.name = "open"
    }
    
    override func execute(_ player: Player) -> Bool {
        
        if hasSecondWord() && hasThirdWord(){
            if secondWord == "door" || secondWord == "Door"  {
                
                player.openDoor(thirdWord!)
            } else {
                player.warningMessage("\nIf you are trying to open a door, type 'open door exitDirection', ex. open door north")
            }
            
            
        } else if hasSecondWord() == true && hasThirdWord() == false {
            
            if secondWord == "door" || secondWord == "Door" {
                player.warningMessage("\nOpen Door Where?")
                
            } else {
                
                player.warningMessage("\nIf you are trying to open a door, type 'open door exitDirection', ex. open door north")
            }
            
        } else {
            player.warningMessage("\nOpen What?")
        }
        
        return false
    }
}
