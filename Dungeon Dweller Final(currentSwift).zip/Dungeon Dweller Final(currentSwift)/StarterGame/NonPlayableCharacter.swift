//
//  NonPlayableCharacter.swift
//  StarterGame
//
//  Created by csu on 4/22/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// a non playable character to interact with the player, has a name, occupation, backpack for storage, an item it is holding, a desired item, a path it may use to go throughout the world, and a money pouch
class NonPlayableCharacter {
    var name : String
    var occupation : String
    var backpack : Backpack = Backpack(name : "NPC's Backpack" , weight: 0.0, value: 0, limit: 1000.00)
    var response : String?
    var responseCount : integer_t?
    var held : Item?
    var wantsItem : String?
    var conditionMetForItem : Bool?
    var path : [integer_t] = [integer_t]()
    var moneyPouch : MoneyPouch = MoneyPouch(name : "NPC's Money Pouch", contains : 50)
    
    init(npcName : String, npcOccupation : String){
        name = npcName
        occupation = npcOccupation
        
        
    }
    //determines if the npc has a path to follow or not
    func hasPath() -> Bool {
        if getPath().isEmpty == false {
            return true
        } else {
            return false
        }
    }
    //sets the path of the npc
    func setPath(_ newPath : [integer_t]) {
        path = newPath
    }
    //returns the npcs path
    func getPath() -> [integer_t] {
        return path
    }
    //gets money held
    func getMoneyHeld() -> integer_t {
        return moneyPouch.getContents()
    }
    // sets money held
    func setMoneyHeld(_ money : integer_t){
        moneyPouch.setContents(money)
    }
    //adds money to pouch
    func addMoneyHeld(_ money : integer_t){
        moneyPouch.addMoney(money)
    }

    
    // list items the npc is holding
    func listItems() -> String {
        if held != nil {
            if backpack.isEmpty() == true {
                let listing : String = "\n \(getName()) is holding \n * \(getHeldDescription())"
                return listing
            } else {
                var listing : String = "\n \(self.getName()) is holding \n * \(getHeldDescription())"
                listing += backpack.npcListing()
                return listing
            }
        } else {
            if backpack.isEmpty() == true {
                let listing : String = "\n \(self.getName()) has no items "
                return listing
            } else {
                var listing : String = "\n \(self.getName()) is holding "
                listing += backpack.npcListing()
                return listing
            }
            
        }
        
        
    }
    
    //not used
    func conditionNotMet() {
        conditionMetForItem = false
    }
    //not used
    func conditionMet() {
        conditionMetForItem = true
    }
    //not used
    func getConditionState() -> Bool? {
        return conditionMetForItem!
    }
    
    //used to set wanted item of the npc
    func setWantedItem(_ desiredItemName : String) {
        wantsItem = desiredItemName
    }
    //returns npc's wanted item
    func getWantedItem() -> String? {
        return wantsItem
    }
    //stores items in npc's backpack
    func storeInPack(_ item : Item) {
        backpack.store(item)
    }
    //sets held item of npc
    func setHeld(_ thisItem : Item) {
        held = thisItem
    }
    //gets held item of npc
    func getHeld() -> Item? {
        return held
    }
    //gets description of held item
    func getHeldDescription() -> String {
        return (held?.description())!
    }
    //adds all the notifications to the npcs depending on what they should be notified about
    func addNotifications() {
        NotificationCenter.default.addObserver(self, selector : #selector(askedForItem(_ : )), name: NSNotification.Name(rawValue: "AskedForItem"), object : nil)
        
        
        if getOccupation() == "Blacksmith" {
            NotificationCenter.default.addObserver(self, selector: #selector(respondToRepair(_:)), name: NSNotification.Name(rawValue: "RespondToRepair"), object: nil)
        }
        if getOccupation() == "Merchant" {
            NotificationCenter.default.addObserver(self, selector: #selector(respondToBuy(_:)), name: NSNotification.Name(rawValue: "RespondToBuy"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(respondToSell(_:)), name: NSNotification.Name(rawValue: "RespondToSell"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(givenItem(_ : )), name: NSNotification.Name(rawValue: "GivenItem"), object: nil)
        }
        

    }
    //gets npc name
    func getName() -> String {
        return name
    }
    //gets npc occupation
    func getOccupation() -> String {
        return occupation
    }
    //gets description of npc specific format
    func description() -> String {
        return ("\n \(self.getName()) the \(self.getOccupation())")
    }
    //gets description of npc specific format
    func getDescription() -> String {
        return ("\(self.getName()) the \(self.getOccupation())")
    }
    //gets response of npc
    func getResponse() -> String? {
        return self.response
    }
    // sets response of npc
    func setResponse(_ message : String) {
        self.response = message
    }
    // checks if npc is holding item by name, checks their held item first, then the backpack
    func isHoldingNamed(_ itemName : String) -> Bool {
        if held != nil {
            if held?.getName() == itemName {
                return true
            } else {
                if backpack.hasThisItem(itemName) == true {
                    return true
                } else {
                    return false
                }
            }
        } else {
            if backpack.hasThisItem(itemName) == true {
                return true
            } else {
                return false
            }
        }
    }
    
    //this function is a notification handled event specific to the blacksmith, it allows interaction between npc and player, repairs weapon if player can afford it, has a weapon to repair, and if it is already fully repaired
    @objc func respondToRepair(_ notification : Notification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : Weapon]
        let playerWeapon : Weapon = userInfo["playerWeapon"]!
        let cost : integer_t = playerWeapon.getRepairVal()
        if player.currentRoom.hasThisNPCOccupation("Blacksmith") == true {
            if (playerWeapon.getDurability() != playerWeapon.getDurabilityLim()) {
                if player.getMoney() > 0 {
                    if ((player.getMoney() - cost) >= 0 ) {
                        player.setMoney(player.getMoney() - cost)
                        self.addMoneyHeld(cost)
                        playerWeapon.setDurability(playerWeapon.getDurabilityLim())
                        playerWeapon.weaponFixed()
                        player.outputMessage("\nYour \(playerWeapon.getName()) was repaired for \(cost) gold")
                        player.changedMyStats() //new
                    } else {
                        player.warningMessage("\nYou do not have the money to repair the \(playerWeapon.getName()) this costs \(cost) gold to repair")
                    }
                    
                } else {
                    player.warningMessage("\nYou do not have any money to repair your \(playerWeapon.getName())")
                }
            } else {
                player.warningMessage("\nYour \(playerWeapon.getName()) is already fully repaired")
            }
        }
        
    }
    
    
    //this function is a notification handled event specific to the merchant, it allows interaction between npc and player, gives player items to their backpack if player can afford it, can hold the item, and updates stats, and if the npc has the item
    @objc func respondToBuy(_ notification : Notification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : String]
        let desiredItem : String = userInfo["desiredItem"]!
        
        if self.isHoldingNamed(desiredItem) == true {
            if held != nil {
                if held?.getName() == desiredItem {
                    let thisItem : Item = held!
                    if (player.getMoney() - thisItem.getValue()) >= 0 {
                        if player.canHold(thisItem) == true {
                            let remaining : integer_t = (player.getMoney() - thisItem.getValue())
                            player.receiveItem(thisItem)
                            player.setMoney(remaining)
                            player.outputMessage("\nYou purchased the \(thisItem.getName()) for \(thisItem.getValue()) gold, it was added to your backpack, you now have \(remaining) gold left")
                            self.held = nil
                            player.changedMyStats() //new
                        } else {
                            player.warningMessage("\nYou cannot hold that \(thisItem.getName()), you need to make room in your backpack before you buy it")
                        }
                        
                    } else {
                        player.warningMessage("\nYou cannot afford that! You need \(thisItem.getValue()) gold to buy this!")
                    }
                    
                } else {
                    let thisItem : Item = backpack.peekItem(desiredItem)!
                    if (player.getMoney() - thisItem.getValue()) >= 0 {
                        if player.canHold(thisItem) == true {
                            let remaining : integer_t = (player.getMoney() - thisItem.getValue())
                            player.receiveItem(thisItem)
                            backpack.retrieve(desiredItem)!
                            player.setMoney(remaining)
                            player.outputMessage("\nYou purchased the \(thisItem.getName()) for \(thisItem.getValue()) gold, it was added to your backpack, you now have \(remaining) gold left")
                            player.changedMyStats() //new
                            
                        } else {
                            player.warningMessage("\nYou cannot hold that \(thisItem.getName()), you need to make room in your backpack before you buy it")
                        }
                        
                    } else {
                        player.warningMessage("\nYou cannot afford that! You need \(thisItem.getValue()) gold to buy this!")
                    }
                    
                }
            } else {
                let thisItem : Item = backpack.retrieve(desiredItem)!
                if (player.getMoney() - thisItem.getValue()) >= 0 {
                    if player.canHold(thisItem) == true {
                        let remaining : integer_t = (player.getMoney() - thisItem.getValue())
                        player.receiveItem(thisItem)
                        player.setMoney(remaining)
                        player.outputMessage("\nYou purchased the \(thisItem.getName()) for \(thisItem.getValue()) gold, it was added to your backpack, you now have \(remaining) gold left")
                        player.changedMyStats() //new
                        
                    } else {
                        player.warningMessage("\nYou cannot hold that \(thisItem.getName()), you need to make room in your backpack before you buy it")
                    }
                    
                } else {
                    player.warningMessage("\nYou cannot afford that! You need \(thisItem.getValue()) gold to buy this!")
                }
                
                
            }
        } else {
            player.warningMessage("\n\(self.getName()) does not have that item")
        }
    }
    //notification handled event if a player sells an item they have to the npc, it updates their stats and gives them gold for it, checks if given from the hand or from the backpack
    @objc func respondToSell(_ notification : Notification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : String]
        let sellItem : String = userInfo["sellingItem"]!
        let givenFrom : String = userInfo["givenFrom"]!
        if givenFrom == "hand" {
            let itemSold : Item = player.takeFromHand()!
            let itemVal : integer_t = itemSold.getSellValue()
            storeInPack(itemSold)
            player.increaseMoney(itemVal)
            player.outputMessage("\nYou successfully sold the \(itemSold.getName()) from your hands for \(itemVal) gold, you now have \(player.getMoney()) gold")
            player.changedMyStats() //new
        } else {
            let itemSold : Item = player.takeFromPack(sellItem)!
            let itemVal : integer_t = itemSold.getSellValue()
            storeInPack(itemSold)
            player.increaseMoney(itemVal)
            player.outputMessage("\nYou successfully sold the \(itemSold.getName()) from your backpack for \(itemVal) gold, you now have \(player.getMoney()) gold")
            player.changedMyStats() //new
        }
        
        
    }
    
    //notification handled event if the npc wants the item that the player gives them, they will respond in a certain way
    @objc func givenItem(_ notification : Notification) {
        let strBackpack : String = "backpack"
        
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : String]
        let theGivenItem : String = userInfo["givenItem"]!
        let desiredCharacter : String = userInfo["desiredCharacter"]!
        let givenFrom : String = userInfo["givenFrom"]!
        
        if player.currentRoom.hasThisNPC(desiredCharacter) {
            if getWantedItem() != nil {
                if theGivenItem == getWantedItem() {
                    if givenFrom == strBackpack {
                        let itemTaken : Item = player.takeFromPack(theGivenItem)!
                        storeInPack(itemTaken)
                        player.outputMessage("\nYou successfully gave the \(itemTaken.getName()) from your backpack to \(desiredCharacter)")
                        player.outputMessage("\n \(desiredCharacter) said: The weapon voucher expired yesterday, sorry dungeon dweller")
                         //possible notification spot
                        
                    } else {
                        let itemTaken : Item = player.takeFromHand()!
                        storeInPack(itemTaken)
                        player.outputMessage("\nYou successfully gave the \(itemTaken.getName()) from your hand to \(desiredCharacter), you are now empty handed")
                        player.outputMessage("\n \(desiredCharacter) said: The weapon voucher expired yesterday, sorry dungeon dweller")
                        //possible notification spot
                    }
                } else {
                    player.warningMessage("\n \(desiredCharacter) doesn't want the \(theGivenItem)")
                }
            } else {
                player.warningMessage("\n \(desiredCharacter) doesn't want the \(theGivenItem)")
            }

        }
        
        
        
        
    }
    //takes item from npc pack
    func takeFromPack(_ itemName : String) -> Item? {
        if  backpack.hasThisItem(itemName) == true {
            let thisItem : Item? = backpack.retrieve(itemName)
            return thisItem
        } else {
            return nil
        }
    }

    
    //unused code
    /*@objc func respondToItemGiven(notification : NSNotification) {
        
        
    }*/
    
    
    
    
    //notification handled event if the player asks the npc for an item, the npc checks if the player has met the condition for the item, and gives it to them if they have met the condition
    @objc func askedForItem(_ notification : Notification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : String]
        let desiredItem : String = userInfo["desiredItem"]!
        if player.currentRoom.hasThisNPC(self.getName()) {
            if held != nil {
                if (held?.getName() == desiredItem) {
                    if player.canHold(held!) == true {
                        if getConditionState() == true {
                            player.receiveItem(held!)
                            player.outputMessage("\nThe \(held!.getName()) was placed in your backpack ")
                            //possible notification spot
                            held = nil
                        } else {
                            player.warningMessage("\n \(self.getDescription()) does not believe you deserve any items")
                        }
                        
                    } else {
                        if getConditionState() == true {
                            player.outputMessage("\nYou are unable to store the item you asked for because you are too weak")
                        } else {
                            player.warningMessage("\n \(self.getDescription()) does not believe you deserve any items")
                        }
                        
                    }
                } else {
                    let thisItem : Item? = giveItem(desiredItem)
                    if thisItem != nil {
                        if player.canHold(thisItem!) == true {
                            if getConditionState() == true {
                                player.receiveItem(thisItem!)
                                player.outputMessage("\nThe \(thisItem!.getName()) was placed in your backpack ")
                                //possible notification spot
                            } else {
                                player.warningMessage("\n \(self.getDescription()) does not believe you deserve any items")
                            }
                        } else {
                            if getConditionState() == true {
                                player.outputMessage("\nYou are unable to store the item you asked for because you are too weak")
                            } else {
                                player.warningMessage("\n \(self.getDescription()) does not believe you deserve any items")
                            }
                            
                        }
                    } else {
                        player.outputMessage("\n \(self.getDescription()) has no items to give you right now")
                    }
                }
            } else {
                let thisItem : Item? = giveItem(desiredItem)
                if thisItem != nil {
                    if player.canHold(thisItem!) == true {
                        if getConditionState() == true {
                            player.receiveItem(thisItem!)
                            player.outputMessage("\nThe \(thisItem!.getName()) was placed in your backpack ")
                            //possible notification spot
                            
                        } else {
                            player.warningMessage("\n \(self.getDescription()) does not believe you deserve any items")
                        }
                    } else {
                        if getConditionState() == true {
                            player.outputMessage("\nYou are unable to store the item you asked for because you are too weak")
                        } else {
                            player.warningMessage("\n \(self.getDescription()) does not believe you deserve any items")
                        }
                        
                    }
                } else {
                    player.outputMessage("\n \(self.getDescription()) has no items to give you right now")
                }
            }

        }
    }
    //gets the item to give the player
    func giveItem(_ itemName : String) -> Item? {
        
        if backpack.isEmpty() == false {
            let thisItem : Item? = backpack.retrieve(itemName)
            if thisItem != nil {
    
                return thisItem
            } else {
    
                return nil
            }
        } else {
            return nil
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    
    
    
    
    
    
    
    
}
