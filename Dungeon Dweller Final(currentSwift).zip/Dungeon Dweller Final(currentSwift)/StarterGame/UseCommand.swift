//
//  UseCommand.swift
//  StarterGame
//
//  Created by csu on 4/25/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows player to use an item on something, works specifically with the cell lockpick on the cell door, must be three word command
class UseCommand : Command {
    override init() {
        super.init()
        self.name = "use"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasThirdWord() && hasSecondWord() {
            player.useItem(secondWord!, thing: thirdWord!)
        } else if hasSecondWord(){
            player.warningMessage("\n Use \(secondWord!) Where?")
        } else {
            player.warningMessage("\n Use What?")
        }
        return false
    }
    
    
}
