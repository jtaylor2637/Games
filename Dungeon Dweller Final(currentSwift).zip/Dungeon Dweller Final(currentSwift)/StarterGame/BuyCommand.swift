//
//  BuyCommand.swift
//  Dungeon Dweller
//
//  Created by csu on 5/1/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows the player to buy items from the merchant in the game, only works if they specify the item they wish to buy
class BuyCommand : Command {
    override init() {
        super.init()
        self.name = "buy"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasSecondWord() {
            player.buy(secondWord!)
        } else {
            player.warningMessage("\nBuy What?")
        }
        return false
    }
}
