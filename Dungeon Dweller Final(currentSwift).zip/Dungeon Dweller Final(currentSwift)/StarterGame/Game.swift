//
//  Game.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation




// does all of the game creation and allows the player to play or not
class Game {
    
    var player : Player?
    var parser : Parser
    var playing : Bool
    var statsIO : GameOutput?
    
    init(gameIO : GameOutput) {
        playing = false
        parser = Parser(newCommands: CommandWords())
        player = Player(room: GameWorld.sharedInstance.entrance, output: gameIO)
        player?.addNotifications()
        // add necessary notifications for ending game, player dying, or stats changing
        NotificationCenter.default.addObserver(self, selector : #selector(endGame(_ : )), name: NSNotification.Name(rawValue: "EndTheGame"), object : nil)
        NotificationCenter.default.addObserver(self, selector: #selector(playerDied(_:)), name: NSNotification.Name(rawValue: "PlayerDied"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(initialStats(_:)), name: NSNotification.Name(rawValue: "PlayerInitialStats"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(statChange(_:)), name: NSNotification.Name(rawValue: "PlayerChangedStats"), object: nil)
        
    }
    
    //initial output of stats screen
    @objc func initialStats(_ notification : Notification) {
        
        statsIO?.clear()
        statsIO?.sendLine("My stats are: \nHealth: \(20) / \(20) \nDamage: \(2) / \(2) \nStrength: \(1) / \(1) \nDefense: \(1) / \(1) \nCurrent Weight: \(0.0) / \(20.0) \nMoney Held: \(0)")
    }
    
    //setting output of stats screen to a game output class object
    func setStatIO(_ io : GameOutput){
        statsIO = io
    }
    //outputs to the stats screen if a change is necessary
    @objc func statChange(_ notification : Notification) {
        let player : Player = notification.object as! Player
        
        statsIO?.clear()
        statsIO?.sendLine(player.getChangedStats())
        //statsIO?.sendLine("My stats are: \nHealth: \(player.getHealth()) / \(player.getTotalHealth())")
        //statsIO?.sendLine("\nDamage: \(player.getMyBaseDamage()) / \(player.getTotalDamage())")
            //\nStrength: \(player.getMyStr()) / \(player.getTotalStr()) \nDefense: \(player.getMyDef()) / \(player.getTotalDef())")
        //statsIO?.sendLine("\(player.getHealth())")
    }
    
    //starts game
    func start() {
        playing = true
        player?.outputMessage(welcome())
    }
    //ends game
    func end() {
        playing = false
        player?.outputMessage(goodbye())
    }
    //quits game
    func quit() {
        playing = false
        player?.outputMessage("\nYou quit the game! Thanks for playing!")
    }
    //tells if you were killed by an enemy
    func killed(_ enemy : String) {
        playing = false
        player?.outputMessage(died(enemy))
    }
    //end game screen for game over
    func died(_ enemy : String) -> String {
        return ("\nYou tried your best to escape the dungeon, but you were killed by a \(enemy) better luck next time! \n \n -------------------------------------------------------------GAME OVER---------------------------------------------------------------- \n \n")
        
    }
    //welcome message
    func welcome() -> String {
        let message = "You wake up in a dimly lit, moist, and eerie dungeon. You probably should try to (search) for a way out! Good luck!\n\nThis dungeon crawler is a new and challenging escape adventure game.\n\nType 'help' if you need help, but you probably won't get much. "
        return "\(message)\n\n\(player!.currentRoom.description())"
        
    }
    //you win message
    func goodbye() -> String {
        return "\nYou managed to escape the dungeon, you should leave this place before something bad happens. \n \n -------------------------------------------------------------YOU WON---------------------------------------------------------------- \n \n"
    }
    //executes commands entered into the command box and removes spaces for the parser
    func execute(_ commandString : String) -> Bool {
        let commandStr : String = commandString.trimmingCharacters(in: CharacterSet.whitespaces)
        //remove ^ if parser breaks, and the if commandstr != ""
        var finished : Bool = false
        if commandStr != "" {
            if playing {
                player?.commandMessage("\n>\(commandString)")
                let command : Command? = parser.parseCommand(commandString)
                if command != nil {
                    if command?.name == "quit" {
                        quit()
                    } else if command?.name == "consume"{
                        finished = (command?.execute(player!))!
                    
                    } else {
                        if command?.name != "attack" {
                            NotificationCenter.default.post(name: Notification.Name(rawValue: "playerEnteredCommand"), object: player)
                        }
                        finished = (command?.execute(player!))!
                    }
                    
                } else {
                    NotificationCenter.default.post(name: Notification.Name(rawValue: "playerEnteredCommand"), object: player)
                    player?.errorMessage("\nI don't understand what you are typing...")
                }
            }

        }
        return finished
    }
    //ends the game
    @objc func endGame(_ notification : Notification) {
        self.end()
    }
    //ends the game because player died
    @objc func playerDied(_ notification : Notification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : String]
        let enemyKilledBy = userInfo["killedBy"]
        killed(enemyKilledBy!)
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
