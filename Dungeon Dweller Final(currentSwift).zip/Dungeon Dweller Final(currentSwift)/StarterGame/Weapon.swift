//
//  Weapon.swift
//  StarterGame
//
//  Created by csu on 4/22/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// weapon class is a subclass of items which is used to deal damage to enemies, has the name, a durability max limit, a current durability, broken state
class Weapon : Item {
    var damage : integer_t
    var durabilityLim : float_t
    var durability : float_t
    var broken : Bool = false
    
    
    init(name: String, weight : float_t, value : integer_t, thisDamage : integer_t, thisdurability : float_t) {
        damage = thisDamage
        durability = thisdurability
        
        durabilityLim = thisdurability
        super.init(name: name, weight: weight, value: value)
    }
    
    func getDamage() -> integer_t{
        return self.damage
    }
    
    func setDamage(_ dmg : integer_t){
        self.damage = dmg
    }
    
    func getDurability() -> float_t{
        return self.durability
    }
    
    func setDurability(_ dmg : float_t){
        self.durability = dmg
    }
    
    func getDurabilityLim() -> float_t {
        return self.durabilityLim
    }
    
    func weaponBreaks() {
        self.broken = true
    }
    
    func weaponFixed() {
        self.broken = false
    }
    
    func isBroken() -> Bool {
        return self.broken
    }
    //gets a repair value based on the damaged state of the item, and its original cost
    func getRepairVal() -> integer_t {
        var repVal : float_t = self.getDurabilityLim()
        repVal -= self.getDurability()
        repVal *= 10
        repVal += float_t(self.getValue() / 2)
        return integer_t(repVal)
    }
    
    override func isWeapon() -> Bool {
        return true
    }
    
    
    override func description() -> String {
        return "\(name) with weight \(self.getWeight()) and value \(self.getValue()) and does \(self.getDamage()) damage. It has a durability of \(self.getDurability())"
    }
    
}
