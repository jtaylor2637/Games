//
//  HelpCommand.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// displays list of available commands to the user, and a message regarding the game, no real help given, figure out the game, noob, git gud
class HelpCommand: Command {
    var words : CommandWords
    
    init(commands : CommandWords) {
        words = commands
        super.init()
        self.name = "help"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasSecondWord() {
            player.warningMessage("\nI cannot help you with '\(secondWord!)'")
        } else {
            player.outputMessage("\nYou are somewhere in a dungeon, hopefully trying to escape.\n\nYour available commands are:\n\(words.description())")
        }
        return false
    }
}
