//
//  Door.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//door class which connects two rooms, has a lock type and a key to the lock
class Door : Lockable {
    var room1 : Room
    var room2 : Room
    var opened : Bool
    var lockType : Lockable?
    var originalKey : Item?
    
    init(room1 : Room, room2 : Room) {
        self.room1 = room1
        self.room2 = room2
        self.opened = true
    }
    
    func getRoom(_ fromRoom : Room) -> Room {
        //make room current room if closed
        if fromRoom === room1 {
            return room2
        } else {
            return room1
        }
        // return fromRoom === room1 ? room2 : room1
    }
    
    func lock() {
        if lockType != nil {
            lockType?.lock()
        }
    }
    
    func unlock() {
        if lockType != nil {
            lockType?.unlock()
        }
    }
    
    func isLocked() -> Bool {
        if lockType != nil{
            return (lockType?.isLocked())!
        } else {
            return false
        }
        
    }
    
    func canClose() -> Bool {
        if lockType != nil {
            return (lockType?.canClose())!
        } else {
            return true
        }
    }
    
    func open() {
        if self.isLocked() == false {
            if isOpen() == false {
                opened = true
            }
            
        }
    }
    
    func close() {
        if self.canClose() {
            opened = false
        }
        
    }
    
    func isOpen() -> Bool {
        return opened
    }
    
    func canRegularPick() -> Bool {
        return (lockType?.canRegularPick())!
    }
    func canMakeShiftPick() -> Bool {
        return (lockType?.canMakeShiftPick())!
    }
    func canMagicPick() -> Bool {
        return (lockType?.canMagicPick())!
        
    }
    
    func insertKey(_ key : Item) -> Bool {
        if lockType != nil {
            return (lockType?.insertKey(key))!
            
        } else {
            return false
        }
    }
    
    func removeKey() -> Item? {
        if lockType != nil {
            return lockType!.removeKey()
        } else {
            return nil
        }
    }
    
    func getOriginalKey() -> Item? {
        return lockType?.getOriginalKey()
    }
    
    func setOriginalKey(_ item : Item) {
        lockType?.setOriginalKey(item)
    }
    
    func setInsertedKey() {
        originalKey = lockType?.getOriginalKey()
    }
    
}
//connects room 1 to room 2 and their exit names
func connectRooms(_ room1 : Room, room2 : Room, exitName1 : String, exitName2 : String) -> Door {
    let aDoor : Door = Door(room1 : room1, room2 : room2)
    room1.setExit(exitName1, door : aDoor)
    room2.setExit(exitName2, door : aDoor)
    return aDoor
}
