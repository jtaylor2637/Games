//
//  TalkToCommand.swift
//  StarterGame
//
//  Created by csu on 4/22/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows player to talk to characters, and the characters respond based on their set responses, the second word is the name of the character you wish to talk to
class TalkToCommand: Command {
    override init() {
        super.init()
        self.name = "talkto"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasSecondWord() {
            player.talkTo(secondWord!)
        } else {
            player.warningMessage("\nTalk To Who?")
        }
        return false
    }
}
