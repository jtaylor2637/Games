//
//  MoneyPouch.swift
//  StarterGame
//
//  Created by csu on 4/28/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//money pouch holds gold for player and npcs
class MoneyPouch {
    var name : String = "Money Pouch"
    var contains : integer_t
    
    init(name : String, contains : integer_t){
        self.name = name
        self.contains = contains
    }
    
    func getName() -> String {
        return self.name
    }
    
    func setContents(_ amount : integer_t){
        self.contains = amount
        
    }
    
    func getContents() -> integer_t{
        return self.contains
    }
    
    func addMoney(_ amount : integer_t){
        self.setContents(self.getContents() + amount)
        
    }
    
    func description() -> String{
        return "Your \(self.getName) has \(self.getContents()) coins."
    }
    
}
