//
//  RetrieveFromBackpack.swift
//  StarterGame
//
//  Created by csu on 4/21/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows player to equip an item from their backpack, if they put the item's name in the command
class RetrieveFromBackpack: Command {
    
    override init() {
        super.init()
        self.name = "equip"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasSecondWord() {
            player.retrieveFromBackpack(secondWord!)
            
        } else {
            player.warningMessage("\n Equip What?")
        }
        return false
    }
}
