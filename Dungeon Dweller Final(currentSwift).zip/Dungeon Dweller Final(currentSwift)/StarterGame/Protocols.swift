//
//  Protocols.swift
//  StarterGame
//
//  Created by csu on 4/21/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//lockable protocol which sets the interface for lock types
protocol Lockable {
    func lock()
    func unlock()
    func isLocked() -> Bool
    func canClose() -> Bool
    func canRegularPick() -> Bool
    func canMakeShiftPick() -> Bool
    func canMagicPick() -> Bool
    func insertKey(_ key : Item) -> Bool
    func removeKey() -> Item?
    func getOriginalKey() -> Item?
    func setOriginalKey(_ item : Item)
    func setInsertedKey()
}
//protocol RoomProtocol {
    //func say(message : String) -> String
//}

//protocol to check if item is a consumable
protocol Consumables {
    func isConsumable() -> Bool
}
