//
//  Room.swift
//  StarterGame
//
//  Created by JMK Productions on 3/16/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation

// this is the room class, it has a dictionary of the npcs, enemies, exits, and items. It also has a tag describing the room, a search description which is more detailed to provide hints to player about game solution, search count to change the set description of the room
class Room {
    var NPCList : [String : NonPlayableCharacter]
    var enemyList : [String : Enemy]
    var exits : [String : Door]
    var tag : String
    
    
    var itemList : [String : Item]
    var searchDescription : String?
    var searchCount : integer_t
    var name : String
    convenience init() {
        self.init(tag: "No Tag", roomName: "No Name")
    }
    
    init(tag : String, roomName : String) {
        exits = [String : Door]()
        self.tag = tag
        name = roomName
        itemList = [String : Item]()
        NPCList = [String : NonPlayableCharacter]()
        enemyList = [String : Enemy]()
        searchCount = 0
        
    }
    
    
    // sets the exit of the room to a door at a direction
    func setExit(_ exitName : String, door : Door?) {
        if door == nil {
            exits.removeValue(forKey: exitName)
        } else {
            exits[exitName] = door
        }
     }
    
    //sets the search description of the room
    func setRoomSearchDescription(_ newSearch : String) {
        
        searchDescription = "\nYou are currently \(tag) \n\(newSearch)"
        
    }
    //increases search count to change room description
    func increaseSearchCount() {
            searchCount += 1
    }
    //returns search count
    func getSearchCount() -> integer_t? {
        return searchCount
    }
    //returns the room name
    func getName() -> String {
        return name
    }
    //returns room description
    func getSearchDescription() -> String? {
        if searchDescription != nil {
            return searchDescription
        } else {
            return "\nYou find nothing out of the ordinary"
        }
        
    }
    
    //gets an exit door
    func getExit(_ exitName : String) -> Door? {
        return exits[exitName]
    }
    //gets all exits of the current room
    func getExits() -> String {
        let exitNames : [String] = [String](exits.keys)
        return "Exits: " + exitNames.joined(separator: ", ")
    }
    //returns room's description
    func description() -> String {
        
        return "You are currently \(tag).\n *** \(self.getExits())"
        
    }
    // this is where the player gets the item's description
    func describe(_ itemName : String) -> String {
        if itemList.isEmpty == false {
            if itemList[itemName] != nil {
                let thisItem : Item = (itemList[itemName])!
                return (thisItem.description())
            
            } else {
                return ("\nThere is no item named \(itemName) here")
            }
        } else {
            return "\nThere is no item(s) here"
        }
    }
    
    // this is where items in the room are listed
    func listItems() -> String {
        if itemList.isEmpty == false {
            return self.getItemList()
        } else {
            return "\nThere is no item(s) here."
        }
    }
    //used to add items to the room from game world or enemy drops, player drops etc.
    func addItem(_ thisItem : Item) {
        itemList[thisItem.name] = thisItem
        
    }
    //removes item from the room dictionary when events occur like player pickup
    func removeItem(_ itemName : String) -> Item? {
        let thisItem : Item? = (itemList.removeValue(forKey: itemName))
        return thisItem
    }
    //checks whether room has this item or not
    func hasThisItem(_ itemName : String) -> Bool {
        if itemList.isEmpty == false {
            
            if (itemList[itemName]) != nil {
                
                return true
                
            } else {
                
                return false
                
            }
        } else {
            
            return false
            
        }
    }

    
    // adds an npc to the room, used in game world
    func addNPC(_ character : NonPlayableCharacter) {
        NPCList[character.getName()] = character
    }
    
    //removes selected npc from room by name
    func removeNPC(_ characterName : String) -> NonPlayableCharacter? {
        let thisNPC : NonPlayableCharacter? = (NPCList.removeValue(forKey: characterName))
        return thisNPC
    }
    
    
    
    // checks if the room has this npc by name
    func hasThisNPC(_ characterName : String) -> Bool {
        if NPCList.isEmpty == false {
            
            if (NPCList[characterName]) != nil {
                
                return true
                
            } else {
                
                return false
                
            }
        } else {
            
            return false
            
        }
    }
    
    //checks if room has this npc by occupation
    func hasThisNPCOccupation(_ characterOcc : String) -> Bool {
        if NPCList.isEmpty == false {
            for npc in NPCList.values {
                if npc.getOccupation() == characterOcc {
                    return true
                }
            }
            return false
        } else {
            return false
        }
    }

    // adds enemies to room
    func addEnemy(_ monster : Enemy) {
        enemyList[monster.getName()] = monster
    }
    //gets the list of enemies in the room
    func getEnemyList() -> String {
        if enemyList.isEmpty == false {
            var listing : String = "\n \nThe enemy(s) in the room are \n"
            
            for enemies in enemyList.values {
                listing += " * \(enemies.getDescription())"
            }
            return listing

        } else {
            let listing : String = "\n \nThere are no enemies in the room"
            return listing
        }
        
        
    }
    // removes this enemy by name from the room, occurs when enemy dies
    func removeEnemy(_ enemyName : String) -> Enemy? {
        let thisEnemy : Enemy? = (enemyList.removeValue(forKey: enemyName))
        return thisEnemy
    }
    //checks if the enemy is in the room
    func hasThisEnemy(_ enemyName : String) -> Bool {
        if enemyList.isEmpty == false {
            
            if (enemyList[enemyName]) != nil {
                return true
            } else {
                return false
            }
        } else {
            return false
        }
    }

    
    //this is how the npcs communicate with the player
    func getResponseFrom(_ characterName : String) -> String {
        if NPCList.isEmpty == false {
            if (NPCList[characterName]) != nil {
                let thisNPC : NonPlayableCharacter? = (NPCList[characterName])!
                let thisResponse : String? = thisNPC!.getResponse()
                    if thisResponse != nil {
                        return ("\n \(thisNPC!.getName()) responded with \((thisResponse)!)")
                    } else {
                        return ("\n \(thisNPC!.getName()) does not feel like talking")
                    }
            } else {
                return ("\nThere are no characters named \(characterName) in the room to talk to")
            }
        } else {
            return ("\nThere are no characters in the room to talk to")
        }
        
        
    }
    
    //gets the list of npcs in the room
    func getNPCList() -> String {
        if NPCList.isEmpty == false {
            var listing : String = "\n \nThe characters in the room are "
            
            for npcs in NPCList.values {
                listing += "\n * \(npcs.getDescription())"
            }
            
            for npcItems in NPCList.values {
                listing += "\n \(npcItems.listItems())"
            }
            return listing
        } else {
            return ("\nThere are no characters in the room")
        }
        
    }
    
    //gets the list of items in the room
    func getItemList() -> String {
        var listing : String = "\n \nThe items in the room are "
        
        for names in itemList.keys {
            listing += "\n * \(names)"
        }
        return listing
    }
    
    deinit {
        tag = ""
        exits.removeAll()
    }
}
