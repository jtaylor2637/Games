//
//  CommandWords.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
import Cocoa
// the list of commands available to the user, must be updated everytime a new command is added
class CommandWords {
    var commands : [String : Command]
    
    convenience init() {
        self.init(commandList: [GoCommand(), QuitCommand(), DescribeCommand(), StoreInBackpack(), OpenCommand(), UnlockCommand(), RetrieveFromBackpack(), DropCommand(), PickupCommand(), TalkToCommand(), AskForItemCommand(), GiveCommand(), ListInventoryCommand(), SearchCommand(), UseCommand(), ListCommand(), StatsCommand(), AttackCommand(), ConsumeCommand(), BackCommand(), RepairCommand(), BuyCommand(), SellCommand(), LookCommand(), InvestigateCommand()])
    }
    
    init(commandList : [Command]) {
        commands = [String : Command]()
        for command in commandList {
            commands[command.name] = command
        }
        let help : HelpCommand = HelpCommand(commands: self)
        commands[help.name] = help
    }
    
    func get(_ word : String) -> Command? {
        return commands[word]
    }
    
    func description() -> String {
        return commands.keys.joined(separator: ", ")
    }
}
