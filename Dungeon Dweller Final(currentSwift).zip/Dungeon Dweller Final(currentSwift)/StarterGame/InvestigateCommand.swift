//
//  InvestigateCommand.swift
//  Dungeon Dweller
//
//  Created by csu on 5/2/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// performs the search commands as necessary but allows for user to input investigate if they did not use search, for flexibility in user mindset
class InvestigateCommand : Command {
    override init() {
        super.init()
        self.name = "investigate"
    }
    
    override func execute(_ player: Player) -> Bool {
        if hasSecondWord() {
            if secondWord == "room" {
                player.search()
            } else {
                player.searchSomething(secondWord!)
            }
            
        } else {
            player.search()
        }
        return false
    }
}
