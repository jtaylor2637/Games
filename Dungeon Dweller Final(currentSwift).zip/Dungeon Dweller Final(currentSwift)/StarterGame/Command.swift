//
//  Command.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// class command which checks for second and or third word commands in order for player to execute said command
class Command {
    var name : String
    var secondWord : String?
    var thirdWord : String?
    init() {
        self.name = ""
    }
    
    func hasSecondWord() -> Bool {
        return secondWord != nil
    }
    
    func hasThirdWord() -> Bool {
        return thirdWord != nil
    }
    
    func execute(_ player : Player) -> Bool {
        return false
    }
}
