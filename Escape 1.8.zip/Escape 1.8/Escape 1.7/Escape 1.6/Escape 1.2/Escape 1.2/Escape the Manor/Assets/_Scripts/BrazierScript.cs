﻿using UnityEngine;
using System.Collections;
using System;
public class BrazierScript : MonoBehaviour {
	Animator brazierAnimator;
	public bool lit;
	public Sprite brazier;
	public bool closeby;
	public GameObject door;
	public bool startLit;
	public AudioClip lite;

	// Use this for initialization
	void Start () {	
		PlayerScript.interacted += Switch;	
		brazierAnimator = gameObject.GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (lit == true) {
			brazierAnimator.SetBool ("Lit", true);
		} else {
			brazierAnimator.SetBool ("Lit", false);
			gameObject.GetComponent<SpriteRenderer> ().sprite = brazier;
			if (door != null) {
				closeDoor (door);
			}

		}
	}

	void Switch() {
		if (startLit == false) {
			if (closeby == true) {
				if (lit == true) {
					lit = false;
					brazierAnimator.SetBool ("Lit", false);
					gameObject.GetComponent<SpriteRenderer> ().sprite = brazier;
					if (door != null) {
						closeDoor (door);
					}
				} else {
					gameObject.GetComponent<AudioSource> ().clip = lite;
					gameObject.GetComponent<AudioSource> ().Play();
					lit = true;
					//brazierAnimator.SetBool ("Lit", true);

					StartCoroutine (WaitDoor (1.0f));
					//openDoor (door);
					flameOut ();
				}

			}

		}

	}

	void flameOut() {
		StartCoroutine (WaitBrazier(5.0f));
		//lit = false;
		//closeDoor (door);

	}

	IEnumerator WaitDoor(float amount) {
		yield return new WaitForSeconds (amount);
		if (door != null) {
			openDoor (door);
		}


	}

	IEnumerator WaitBrazier(float amount) {
		yield return new WaitForSeconds (amount);
		lit = false;
		brazierAnimator.SetBool ("Lit", false);
		if (door != null) {
			closeDoor (door);
		}

	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			closeby = true;
		}
	}

	void OnTriggerExit2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			closeby = false;
		}
	}

	void openDoor(GameObject aDoor) {
		aDoor.GetComponent<SpriteRenderer> ().enabled = false;
		aDoor.GetComponent<BoxCollider2D> ().enabled = false;

	}

	void closeDoor(GameObject aDoor) {
		aDoor.GetComponent<SpriteRenderer> ().enabled = true;
		aDoor.GetComponent<BoxCollider2D> ().enabled = true;

	}


}
