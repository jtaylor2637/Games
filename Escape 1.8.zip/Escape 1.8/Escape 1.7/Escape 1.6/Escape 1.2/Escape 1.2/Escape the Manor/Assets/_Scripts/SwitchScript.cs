﻿using UnityEngine;
using System.Collections;

public class SwitchScript : MonoBehaviour {
	public Sprite switchPressed;
	public Sprite switchUp;
	public bool pressed = false;
	public GameObject door;
	public int switchType = 0;
	// Use this for initialization
	void Start () {
		gameObject.GetComponent<SpriteRenderer> ().sprite = switchUp;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			if (switchType == 0) {
				if (pressed == false) {
					gameObject.GetComponent<SpriteRenderer> ().sprite = switchPressed;
					pressed = true;

					gameObject.GetComponent<AudioSource> ().Play();
					door.SetActive (false);
				}

			} else {

				if (pressed == false) {
					gameObject.GetComponent<SpriteRenderer> ().sprite = switchPressed;
					pressed = true;

					gameObject.GetComponent<AudioSource> ().Play();
					door.SetActive (true);
				}




			}

		}
	}

}
