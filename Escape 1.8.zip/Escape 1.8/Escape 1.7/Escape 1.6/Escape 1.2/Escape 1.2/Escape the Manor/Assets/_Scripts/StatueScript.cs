﻿using UnityEngine;
using System.Collections;

public class StatueScript : MonoBehaviour {
	public Vector3 original;
	public bool atStartPoint;
	public Vector3 lastPos;
	// Use this for initialization
	void Start () {
		//gameObject.GetComponent<AudioSource> ().time = .025f; 

		lastPos = transform.position;
		original = gameObject.transform.position;
		atStartPoint = true;
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position != original) {
			atStartPoint = false;
		}
		if (transform.position != lastPos) {
			
			gameObject.GetComponent<AudioSource> ().Play();

			//gameObject.GetComponent<AudioSource> ().Stop();
				
		}

		lastPos = transform.position;
	}



}
