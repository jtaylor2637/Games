﻿using UnityEngine;
using System.Collections;

public class SwordScript : MonoBehaviour {
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.tag == "EnemyHitbox") {
			//print ("collided enemy " + other.transform.root.gameObject.name);
			//EnemyScript enemy = other.gameObject.GetComponent<EnemyScript> ();
			if (other.transform.root.gameObject.name == "miniboss") {
				MiniBossScript mini = other.transform.root.gameObject.GetComponent<MiniBossScript> ();
				if (mini != null) {
					mini.takeDamage ();
				}
			} else {
				EnemyScript enemy = other.transform.root.gameObject.GetComponent<EnemyScript> ();
				if (enemy != null) {
					//print ("take damage here");
					enemy.takeDamage ();
				}
			}

			//gameObject.GetComponentInParent<PlayerScript> ().attackEnemy();


		}
	}


}
