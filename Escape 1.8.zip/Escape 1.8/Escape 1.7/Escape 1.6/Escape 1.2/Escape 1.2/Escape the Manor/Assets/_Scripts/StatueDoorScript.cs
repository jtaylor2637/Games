﻿using UnityEngine;
using System.Collections;
using System;
public class StatueDoorScript : MonoBehaviour {
	
	public StatuePlateScript left;
	public StatuePlateScript right;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (left != null && right != null) {
			if (left.active == true && right.active == true) {
				gameObject.GetComponent<SpriteRenderer> ().enabled = false;
				gameObject.GetComponent<BoxCollider2D> ().enabled = false;
			} else {
				gameObject.GetComponent<SpriteRenderer> ().enabled = true;
				gameObject.GetComponent<BoxCollider2D> ().enabled = true;
			}
		}

	}
}
