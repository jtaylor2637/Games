﻿using UnityEngine;
using System.Collections;

public class LockedDoor : MonoBehaviour {
	public int doortype;
	public AudioClip open;
	public AudioClip close;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			if (doortype == 1) {
				if (other.gameObject.GetComponent<PlayerScript> ().bossKeyCount > 0) {
					other.gameObject.GetComponent<PlayerScript> ().useBossKey ();
					gameObject.GetComponent<SpriteRenderer> ().enabled = false;
					gameObject.GetComponent<BoxCollider2D> ().enabled = false;
					gameObject.GetComponent<CircleCollider2D> ().enabled = false;
					gameObject.GetComponent<AudioSource> ().clip = open;
					gameObject.GetComponent<AudioSource> ().Play();
				}
			} else {
				if (other.gameObject.GetComponent<PlayerScript> ().keyCount > 0) {
					other.gameObject.GetComponent<PlayerScript> ().useKey ();
					gameObject.GetComponent<SpriteRenderer> ().enabled = false;
					gameObject.GetComponent<BoxCollider2D> ().enabled = false;
					gameObject.GetComponent<CircleCollider2D> ().enabled = false;
					gameObject.GetComponent<AudioSource> ().clip = open;
					gameObject.GetComponent<AudioSource> ().Play();
				}
			}
		}

	}


}
