﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class HealthController : MonoBehaviour {
	public GameObject firstHeart;
	public GameObject secHeart;
	public GameObject thirdHeart;
	float health;
	float fullHealth;
	public Sprite fullHeart;
	public Sprite halfHeart;
	public Sprite emptyHeart;
	public static event Action died;
	// Use this for initialization
	void OnEnable(){
		PlayerScript.damaged += Damaged;
		PlayerScript.healed += Healed;

	}

	void Start () {
		health = GameObject.Find ("Player").GetComponent<PlayerScript>().hp;
		fullHealth = health;


	}
	
	// Update is called once per frame
	void Update () {
		if (health >= 3.0f) {
			//print (health);
			firstHeart.GetComponent<Image>().sprite = fullHeart;
			secHeart.GetComponent<Image>().sprite = fullHeart;
			thirdHeart.GetComponent<Image>().sprite = fullHeart;

		} else if (health >= 2.5f) {
			//print (health);
			firstHeart.GetComponent<Image>().sprite = halfHeart;
			secHeart.GetComponent<Image>().sprite = fullHeart;
			thirdHeart.GetComponent<Image>().sprite = fullHeart;


		} else if (health >= 2.0f) {
			//print (health);
			firstHeart.GetComponent<Image>().sprite = emptyHeart;
			secHeart.GetComponent<Image>().sprite = fullHeart;
			thirdHeart.GetComponent<Image>().sprite = fullHeart;




		} else if (health >= 1.5f) {
			//print (health);
			firstHeart.GetComponent<Image> ().sprite = emptyHeart;
			secHeart.GetComponent<Image> ().sprite = halfHeart;
			thirdHeart.GetComponent<Image> ().sprite = fullHeart;

		} else if (health >= 1.0f) {
			//print (health);
			firstHeart.GetComponent<Image> ().sprite = emptyHeart;
			secHeart.GetComponent<Image> ().sprite = emptyHeart;
			thirdHeart.GetComponent<Image> ().sprite = fullHeart;

		} else if (health >= .5f) {
			//print (health);
			firstHeart.GetComponent<Image> ().sprite = emptyHeart;
			secHeart.GetComponent<Image> ().sprite = emptyHeart;
			thirdHeart.GetComponent<Image> ().sprite = halfHeart;

		} else if (health >= 0.0f) {
			//print (health);
			firstHeart.GetComponent<Image> ().sprite = emptyHeart;
			secHeart.GetComponent<Image> ().sprite = emptyHeart;
			thirdHeart.GetComponent<Image> ().sprite = emptyHeart;
			if(died != null) {
				died ();
			} else {
				//print("Hey");
			}

		}
		
	}

	void FixedUpdate() {

	}

	void Damaged() {

		if(health >= .5f) {
			health -= .5f;
		}

	}

	void Healed() {
		if (health < fullHealth) {
			health += .5f;
		}

	}
}
