﻿using UnityEngine;
using System.Collections;
using System;

public class LeverScript : MonoBehaviour {
	public bool leverUp;
	public bool lit;
	public Sprite upLev;
	public Sprite upHigh;
	public Sprite downLev;
	public Sprite downHigh;
	public GameObject door;
	public bool closeby;

	// Use this for initialization
	void Start () {
		//leverUp = true;
		PlayerScript.interacted += Switch;
		//PlayerScript.interacted += Switch;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	/**void HighLight() {
		if (leverUp == true && lit == true) {
			gameObject.GetComponent<SpriteRenderer> ().sprite = upHigh;
		} else if (leverUp == true && lit == false) {
			gameObject.GetComponent<SpriteRenderer> ().sprite = upLev;
		} else if (leverUp == false && lit == true) {			
			gameObject.GetComponent<SpriteRenderer> ().sprite = downHigh;
		} else if (leverUp == false && lit == false) {			
			gameObject.GetComponent<SpriteRenderer> ().sprite = downLev;
		}

	}**/

	void Switch() {
		if (closeby == true) {
			if (leverUp == true) {
				gameObject.GetComponent<SpriteRenderer> ().sprite = downHigh;
				leverUp = false;

				gameObject.GetComponent<AudioSource> ().Play();
				openDoor (door);
			} else {
				gameObject.GetComponent<SpriteRenderer> ().sprite = upHigh;
				leverUp = true;

				gameObject.GetComponent<AudioSource> ().Play();
				closeDoor (door);
			}
		}

	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			lit = true;
			closeby = true;
			if (leverUp == true) {
				gameObject.GetComponent<SpriteRenderer> ().sprite = upHigh;
			} else {
				gameObject.GetComponent<SpriteRenderer> ().sprite = downHigh;
			}
		}
	}

	void OnTriggerExit2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			lit = false;
			closeby = false;
			if (leverUp == true) {
				gameObject.GetComponent<SpriteRenderer> ().sprite = upLev;
			} else {
				gameObject.GetComponent<SpriteRenderer> ().sprite = downLev;
			}
		}
	}

	void openDoor(GameObject aDoor) {
		aDoor.GetComponent<SpriteRenderer> ().enabled = false;
		aDoor.GetComponent<BoxCollider2D> ().enabled = false;
	}

	void closeDoor(GameObject aDoor) {
		aDoor.GetComponent<SpriteRenderer> ().enabled = true;
		aDoor.GetComponent<BoxCollider2D> ().enabled = true;
	}
}
