﻿using UnityEngine;
using System.Collections;
using System;

public class RoomController : MonoBehaviour {
	public GameObject[] levers;
	public GameObject[] doors;
	public int numDoors;
	public int numLevers;
	public GameObject player;
	bool leverUp = true;
	public Sprite upLev;
	public Sprite upHigh;
	public static event Action<GameObject> closeby;
	public static event Action<GameObject> away;
	// Use this for initialization
	void Start () {
		levers = GameObject.FindGameObjectsWithTag ("lever");
		doors = GameObject.FindGameObjectsWithTag ("door");
		//PlayerScript.interacted += playerInteracted;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void playerInteracted() {
		for (int index = 0; index < levers.Length; index++) {
			if (((player.transform.position - levers[index].transform.position).sqrMagnitude) < .3f) {
				closeby (levers[index]);
				//levers [index].gameObject.GetComponent<SpriteRenderer> ().sprite = upHigh;
			} else {
				away (levers [index]);
				//levers [index].gameObject.GetComponent<SpriteRenderer> ().sprite = upLev;
			}
		}
	}
}
