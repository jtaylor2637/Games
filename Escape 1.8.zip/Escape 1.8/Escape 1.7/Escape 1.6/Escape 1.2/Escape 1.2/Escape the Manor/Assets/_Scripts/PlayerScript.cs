﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;
public class PlayerScript : MonoBehaviour {
	public BoxCollider2D hitbox;
	public BoxCollider2D swordHitbox;
	Vector2 hitboxLocation = new Vector2 (-0.003051179f, -0.006472676f);
	public float hp = 3.0f;
	public float fullHp;
	Animator playAnimator;
	Transform playerTransform;
	private Vector2 moveDir;
	public float speed;
	Vector3 originalLocation = new Vector3 (0, 0, 0);
	Vector3 upRight = new Vector3(1, 1, 0);
	Vector3 upLeft = new Vector3(-1, 1, 0);
	Vector3 downRight = new Vector3(1, -1, 0);
	Vector3 downLeft = new Vector3(-1, -1, 0);
	public static event Action damaged;
	public static event Action healed;
	public static event Action interacted;
	public static event Action attackedEnemy;
	public static event Action gameOv;
	public int keyCount;
	GameObject interObj;
	bool canInteract;
	public bool attacking;
	public bool alive;
	Vector2 temp = new Vector2();
	public Text keyText;
	public int bossKeyCount;
	Vector2 swordUpOffset = new Vector2(0.04398297f, 0.0814535f);
	Vector2 swordDownOffset = new Vector2(0.05034195f, -0.07644019f);
	Vector2 swordRightOffset = new Vector2(0.0826668f, -0.03522238f);
	Vector2 swordLeftOffset = new Vector2(-0.08531638f, -0.0362044f);

	Vector2 swordUpSize = new Vector2(0.03719643f, 0.1421315f);
	Vector2 swordDownSize = new Vector2(0.03931608f, 0.1571196f);
	Vector2 swordRightSize = new Vector2(0.1315214f, 0.05669833f);
	Vector2 swordLeftSize = new Vector2(0.1241026f, 0.04171024f);
	
	public enum States {Idle, UpIdle, LeftIdle, RightIdle, DownWalk, UpWalk, LeftWalk, RightWalk, Dead, DownAttack, UpAttack, LeftAttack, RightAttack}; 
	public States myLastState;
	public States myCurrentState;
	public AudioClip swing;
	public AudioClip injured;
	public AudioClip pickup;
	public AudioClip pickup1;
	// Use this for initialization

	void OnEnable() {
		//print ("unactive");
		HealthController.died += dead;
		//print ("Activate");
		RoomController.closeby += InVicinity;
		RoomController.away += notInVicinity;
		EnemyScript.hit += tookDamage;
		MiniBossScript.hit += tookDamage;
		Collectable.collected += CollectedItem;
	}


	void Start () {
		bossKeyCount = 0;
		keyCount = 0;
		keyText.text = (keyCount.ToString());
		alive = true;
		canInteract = false;
		hp = 3.0f;
		fullHp = hp;
		playAnimator = gameObject.GetComponent<Animator> ();
		playerTransform = gameObject.GetComponent<Transform> ();
		playerTransform.position = originalLocation;
		speed = .40f;
		temp = hitboxLocation;
		myLastState = States.Idle;
		swordHitbox.enabled = false;

	}
	
	// Update is called once per frame
	void Update () {
		if (attacking == true) {
			gameObject.GetComponent<AudioSource> ().clip = swing;
			gameObject.GetComponent<AudioSource> ().Play();
		}
		keyText.text = (keyCount.ToString());
		if (hp > 0.0f) {
			alive = true;
		} else {
			alive = false;
			dead ();
		}
			
		transform.rotation = Quaternion.Euler (45, 0, 0);

		float horizontal = Input.GetAxis ("Horizontal");
		float vertical = Input.GetAxis ("Vertical");


		if (vertical > 0 && horizontal > 0) {
			if (Input.GetMouseButton(0)) {
				myCurrentState = States.UpAttack;
				attacking = true;
				playAnimator.SetInteger ("State", (int)States.UpAttack);
				playerTransform.position += upRight * speed * Time.deltaTime;
			} else {
				myCurrentState = States.UpWalk;
				attacking = false;
				playAnimator.SetInteger ("State", (int)States.UpWalk);
				playerTransform.position += upRight * speed * Time.deltaTime;
			}


		} else if (vertical > 0 && horizontal < 0) {
			if (Input.GetMouseButton (0)) {
				myCurrentState = States.UpAttack;
				attacking = true;
				playAnimator.SetInteger ("State", (int)States.UpAttack);
				playerTransform.position += upLeft * speed * Time.deltaTime;
			} else {
				myCurrentState = States.UpWalk;
				attacking = false;
				playAnimator.SetInteger ("State", (int)States.UpWalk);
				playerTransform.position += upLeft * speed * Time.deltaTime;
			}
					
			
		} else if (vertical < 0 && horizontal > 0) {
			if (Input.GetMouseButton (0)) {
				myCurrentState = States.DownAttack;
				attacking = true;
				playAnimator.SetInteger ("State", (int)States.DownAttack);
				playerTransform.position += downRight * speed * Time.deltaTime;
			} else {
				myCurrentState = States.DownWalk;
				attacking = false;
				playAnimator.SetInteger ("State", (int)States.DownWalk);
				playerTransform.position += downRight * speed * Time.deltaTime;
			}
						
			
		} else if (vertical < 0 && horizontal < 0) {
			if (Input.GetMouseButton (0)) {
				myCurrentState = States.DownAttack;
				attacking = true;
				playAnimator.SetInteger ("State", (int)States.DownAttack);
				playerTransform.position += downLeft * speed * Time.deltaTime;	
			} else {
				myCurrentState = States.DownWalk;
				attacking = false;
				playAnimator.SetInteger ("State", (int)States.DownWalk);
				playerTransform.position += downLeft * speed * Time.deltaTime;	
			}

		} else if (horizontal < 0) {
			if (Input.GetMouseButton (0)) {
				myCurrentState = States.LeftAttack;
				attacking = true;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.LeftWalk;
					playAnimator.SetInteger ("State", (int)States.LeftAttack);
					playerTransform.position += Vector3.left * speed * Time.deltaTime;
				} else {
					playAnimator.SetInteger ("State", (int)States.LeftAttack);
				}
			} else {
				myCurrentState = States.LeftIdle;
				attacking = false;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.LeftWalk;
					playAnimator.SetInteger ("State", (int)States.LeftWalk);
					playerTransform.position += Vector3.left * speed * Time.deltaTime;
				} else {
					playAnimator.SetInteger ("State", (int)States.LeftIdle);
				}
			}

		} else if (horizontal > 0) {
			if (Input.GetMouseButton (0)) {
				myCurrentState = States.RightAttack;
				attacking = true;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.RightWalk;
					playAnimator.SetInteger ("State", (int)States.RightAttack);
					playerTransform.position += Vector3.right * speed * Time.deltaTime;

				} else {
					playAnimator.SetInteger ("State", (int)States.RightAttack);
				}
			} else {
				myCurrentState = States.RightIdle;
				attacking = false;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.RightWalk;
					playAnimator.SetInteger ("State", (int)States.RightWalk);
					playerTransform.position += Vector3.right * speed * Time.deltaTime;

				} else {
					playAnimator.SetInteger ("State", (int)States.RightIdle);
				}
			}

		} else if (vertical < 0) {
			if (Input.GetMouseButton (0)) {
				myCurrentState = States.DownAttack;
				attacking = true;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.DownWalk;
					playAnimator.SetInteger ("State", (int)States.DownAttack);
					playerTransform.position += Vector3.down * speed * Time.deltaTime;

				} else {
					playAnimator.SetInteger ("State", (int)States.DownAttack);
					playerTransform.position += Vector3.down * speed * Time.deltaTime;
				}

			} else {
				myCurrentState = States.Idle;
				attacking = false;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.DownWalk;
					playAnimator.SetInteger ("State", (int)States.DownWalk);
					playerTransform.position += Vector3.down * speed * Time.deltaTime;

				} else {
					playAnimator.SetInteger ("State", (int)States.Idle);
					//playerTransform.position += Vector3.down * speed * Time.deltaTime;
				}

			}


		} else if (vertical > 0) {
			if (Input.GetMouseButton (0)) {
				myCurrentState = States.UpAttack;
				attacking = true;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.UpWalk;
					playAnimator.SetInteger ("State", (int)States.UpAttack);
					playerTransform.position += Vector3.up * speed * Time.deltaTime;

				} else {
					playAnimator.SetInteger ("State", (int)States.UpAttack);
				}
			} else {
				myCurrentState = States.UpIdle;
				attacking = false;
				if (myLastState == myCurrentState) {
					//myCurrentState = States.UpWalk;
					playAnimator.SetInteger ("State", (int)States.UpWalk);
					playerTransform.position += Vector3.up * speed * Time.deltaTime;

				} else {
					playAnimator.SetInteger ("State", (int)States.UpIdle);
				}
			}

//		} else if (Input.GetKeyDown (KeyCode.Space)) {
//			tookDamage ();
//			
//		} else if (Input.GetKeyDown (KeyCode.H)) {
//			foundHealth ();
		} else if (Input.GetKeyDown (KeyCode.E)) {
			interacted ();

		} else if (Input.GetMouseButton(0)) {
			attacking = true;
			if (myLastState == States.UpIdle || myLastState == States.UpWalk) {
				playAnimator.SetInteger ("State", (int)States.UpAttack);
				myCurrentState = States.UpAttack;
			} else if (myLastState == States.LeftIdle || myLastState == States.LeftWalk) {
				playAnimator.SetInteger ("State", (int)States.LeftAttack);
				myCurrentState = States.LeftAttack;
			} else if (myLastState == States.DownWalk || myLastState == States.Idle) {
				playAnimator.SetInteger ("State", (int)States.DownAttack);
				myCurrentState = States.DownAttack;
			} else if (myLastState == States.RightIdle || myLastState == States.RightWalk) {
				playAnimator.SetInteger ("State", (int)States.RightAttack);
				myCurrentState = States.RightAttack;
			}
		

		} else if (vertical == 0 && horizontal == 0) {
			if (alive == true) {
				if (myLastState == States.UpWalk || myLastState == States.UpIdle || myLastState == States.UpAttack) {
					myCurrentState = States.UpIdle;
					playAnimator.SetInteger ("State", (int)States.UpIdle);
					attacking = false;

				} else if (myLastState == States.LeftWalk || myLastState == States.LeftIdle || myLastState == States.LeftAttack) {
					myCurrentState = States.LeftIdle;
					playAnimator.SetInteger ("State", (int)States.LeftIdle);
					attacking = false;

				} else if (myLastState == States.RightWalk || myLastState == States.RightIdle || myLastState == States.RightAttack) {
					myCurrentState = States.RightIdle;
					playAnimator.SetInteger ("State", (int)States.RightIdle);
					attacking = false;

				} else if (myLastState == States.DownWalk || myLastState == States.Idle || myLastState == States.DownAttack) {
					myCurrentState = States.Idle;
					playAnimator.SetInteger ("State", (int)States.Idle);
					attacking = false;

				} 
			}

		}

		myLastState = myCurrentState;

		hitBoxMove ();



	}

	void hitBoxMove() {
		if (myLastState == States.DownAttack) {
			swordHitbox.enabled = true;
			swordHitbox.offset = swordDownOffset;
			swordHitbox.size = swordDownSize;
			temp.x = hitboxLocation.x;
			temp.y = (.07f);
			hitbox.offset = temp;

		} else if (myLastState == States.UpAttack) {
			swordHitbox.enabled = true;
			swordHitbox.offset = swordUpOffset;
			swordHitbox.size = swordUpSize;
			temp.x = hitboxLocation.x;
			temp.y = (-.07f);
			hitbox.offset = temp;

		} else if (myLastState == States.LeftAttack) {
			swordHitbox.enabled = true;
			swordHitbox.offset = swordLeftOffset;
			swordHitbox.size = swordLeftSize;
			temp.y = hitboxLocation.y;
			temp.x = (.08f);
			hitbox.offset = temp;

		} else if (myLastState == States.RightAttack) {
			swordHitbox.enabled = true;
			swordHitbox.offset = swordRightOffset;
			swordHitbox.size = swordRightSize;
			temp.y = hitboxLocation.y;
			temp.x = (-.08f);
			hitbox.offset = temp;

		} else {
			swordHitbox.enabled = false;
			hitbox.offset = hitboxLocation;
		}
	}

	void FixedUpdate() {		

	}


	void CollectedItem (Collectable item) {
		if (item.thisItem == Collectable.ItemType.Heart) {
			foundHealth ();
			foundHealth ();
		} else if (item.thisItem == Collectable.ItemType.Key) {
			foundKey ();
		} else if (item.thisItem == Collectable.ItemType.BossKey) {
			foundBossKey ();
		}
	}

	public void tookDamage() {

		if (hp >= .5f) {			
			hp -= .5f;
			if(damaged != null) {
				damaged();
				gameObject.GetComponent<AudioSource> ().clip = injured;
				gameObject.GetComponent<AudioSource> ().Play();
			}
			if(hp < .5f) {
				alive = false;
				dead();

			}

			//print ("Hit");
		} else if(hp < .5f) {
			alive = false;
			//print ("I should be dead");
			dead();
		}

	}

	void foundHealth() {
		if (hp < fullHp) {
			gameObject.GetComponent<AudioSource> ().clip = pickup;
			gameObject.GetComponent<AudioSource> ().Play();
			hp += .5f;
			if(healed != null) {
				healed ();
			}

		}

	}

	void foundKey() {
		gameObject.GetComponent<AudioSource> ().clip = pickup;
		gameObject.GetComponent<AudioSource> ().Play();
		keyCount++;
	}

	void foundBossKey() {
		gameObject.GetComponent<AudioSource> ().clip = pickup;
		gameObject.GetComponent<AudioSource> ().Play();
		bossKeyCount++;
	}

	public bool useKey() {
		if (keyCount != 0) {
			keyCount --;
			return true;
		}
		return false;
	}

	public bool useBossKey() {
		if (bossKeyCount != 0) {
			bossKeyCount --;
			return true;
		}
		return false;
	}

	public void attackEnemy() {
		if (attackedEnemy != null) {
			attackedEnemy ();
		}

	}

	void dead() {
		
		//print ("die here");
		playAnimator.SetInteger("State", (int)States.Dead);
		//print ("played");
		if (gameOv != null) {
			gameOv ();
		}
	}

	void InVicinity(GameObject obj) {
		canInteract = true;
	}

	void notInVicinity(GameObject obj) {
		canInteract = false;
	}
}
