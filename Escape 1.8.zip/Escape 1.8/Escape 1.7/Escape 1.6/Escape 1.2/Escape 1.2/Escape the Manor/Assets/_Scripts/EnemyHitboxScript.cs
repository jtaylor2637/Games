﻿using UnityEngine;
using System.Collections;

public class EnemyHitboxScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnCollisionEnter2D(Collision2D coll) {
		
		if (coll.gameObject.tag == ("Sword")) {
			if (gameObject.transform.root.gameObject.name == "miniboss") {
				this.gameObject.GetComponentInParent<MiniBossScript> ().takeDamage ();
			} else {
				this.gameObject.GetComponentInParent<EnemyScript> ().takeDamage ();
			}

		} else if (coll.gameObject.tag == ("Player")) {
			if (gameObject.transform.root.gameObject.name == "miniboss") {
				this.gameObject.GetComponentInParent<MiniBossScript> ().hitPlayer ();
			} else {
				this.gameObject.GetComponentInParent<EnemyScript> ().hitPlayer ();
			}

		}

	}
}
