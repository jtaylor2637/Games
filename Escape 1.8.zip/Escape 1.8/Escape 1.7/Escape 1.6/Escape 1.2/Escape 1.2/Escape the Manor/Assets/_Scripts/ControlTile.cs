﻿using UnityEngine;
using System.Collections;

public class ControlTile : MonoBehaviour {
	public KeySwitch switch0;
	public KeySwitch switch1;
	public KeySwitch switch2;
	public KeySwitch switch3;
	public KeySwitch switch4;
	public Collectable hiddenKey;
	public GameObject myDoor;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (hiddenKey != null) {
			if ((switch0.pressed == true) && (switch1.pressed == true) && (switch2.pressed == true) && (switch3.pressed == true) && (switch4.pressed == true)) {
				myDoor.gameObject.SetActive (false);
				hiddenKey.gameObject.SetActive (true);
			}
		}


	}
}
