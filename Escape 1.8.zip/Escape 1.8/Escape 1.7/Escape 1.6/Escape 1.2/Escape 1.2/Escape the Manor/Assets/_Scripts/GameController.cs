﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
public class GameController : MonoBehaviour {
	public GameObject[] rooms;
	public int roomNums = 10;
	// Use this for initialization
	void Start () {
		PlayerScript.gameOv += GameOver;
		TeleportTile.gameWin += GameFinished;
	}
	
	// Update is called once per frame
	void Update () {
	
	}


	void GameOver() {
		//Debug.Log ("GG");
		//SceneManager.UnloadScene ("scene attempt1");
		SceneManager.LoadScene ("gameover", LoadSceneMode.Single);
	}

	void GameFinished() {

		SceneManager.LoadScene ("win", LoadSceneMode.Single);
	}
}
