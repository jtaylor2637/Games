﻿using UnityEngine;
using System.Collections;
using System;
using Random = UnityEngine.Random;
public class EnemyScript : MonoBehaviour {
	Animator enemyAnim;
	public float health = 2.0f;
	public bool closeby;
	Transform enemyTransform;
	public float speed = .15f;
	int ran;
	Transform target;
	Vector3 targetHeading = new Vector3();
	Vector3 targetDirection = new Vector3();
	public static Action hit;
	public enum States {Idle, UpIdle, LeftIdle, RightIdle};
	// Use this for initialization
	public bool alive;
	public GameObject templateDrop;
	public Collectable drop;
	public Vector2 lastPos = new Vector2(0, 0);
	public int dropValue;
	public bool hasDrop;
	public bool verti = false;
	public int wayP = 0;
    public Transform waypoint0;
    public Transform waypoint1;

	public AudioClip alerted;
	public AudioClip damaged;
	public AudioClip killed;
	public int seen = 0;


	void OnEnable() {

		//PlayerScript.attackedEnemy += this.gameObject.GetComponent<EnemyScript>().takeDamage;
	}

	void FixedUpdate() {
		if (closeby == false) {
			if ((waypoint0 != null) && (waypoint1 != null)) {

				if (wayP == 0) {
					if (verti == false) {
						enemyAnim.SetInteger ("State", (int)States.LeftIdle);
					} else {
						enemyAnim.SetInteger ("State", (int)States.Idle);
					}

					transform.position += (waypoint0.position - transform.position) * Time.deltaTime * (speed * 2);
					if(Vector3.Distance(waypoint0.position, transform.position) <= 0.17) {
						wayP = 1;

						//nextWaypoint = (nextWaypoint + 1) % waypoints.length;
					}
				} else if (wayP == 1) {
					if (verti == false) {
						enemyAnim.SetInteger ("State", (int)States.RightIdle);
					} else {
						enemyAnim.SetInteger ("State", (int)States.UpIdle);
					}

					transform.position += (waypoint1.position - transform.position) * Time.deltaTime * (speed * 2);
					if(Vector3.Distance(waypoint1.position, transform.position) <= 0.17) {
						wayP = 0;

						//nextWaypoint = (nextWaypoint + 1) % waypoints.length;
					}
				}

			}
		}
	}
    


	void Start () {
		GameObject tempdrop = Instantiate (templateDrop, transform.position, Quaternion.identity) as GameObject;
		drop = tempdrop.GetComponent<Collectable>();
		drop.gameObject.SetActive (false);
		if (dropValue == 0) {
			drop.thisItem = Collectable.ItemType.Heart;
			hasDrop = true;
		} else if (dropValue == 1) {
			drop.thisItem = Collectable.ItemType.Key;
			hasDrop = true;
		} else if (dropValue == 2) {
			drop.thisItem = Collectable.ItemType.BossKey;
			hasDrop = true;
		} else {
			hasDrop = false;

		}


		alive = true;
		//health = 2.0f;
		//speed = .15f;
		enemyTransform = this.gameObject.GetComponent<Transform> ();
		target = GameObject.FindWithTag ("Player").transform;
		enemyAnim = this.gameObject.GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		
		
		enemyTransform.rotation = Quaternion.Euler (45, 0, 0);
		if (closeby == false) {
			
		} else {
			if (seen == 0) {
				gameObject.GetComponent<AudioSource> ().clip = alerted;
				gameObject.GetComponent<AudioSource> ().Play ();
				seen++;
			}
			enemyTransform.position = Vector2.MoveTowards (enemyTransform.position, target.position, speed * Time.deltaTime);
			if (lastPos.x == 0 && lastPos.y == 0) {
				enemyAnim.SetInteger ("State", (int)States.Idle);
			} else {
				if (transform.position.x < lastPos.x) {
					enemyAnim.SetInteger ("State", (int)States.LeftIdle);
				} else if (transform.position.x > lastPos.x) {
					enemyAnim.SetInteger ("State", (int)States.RightIdle);
				} else if (transform.position.y < lastPos.y) {
					enemyAnim.SetInteger ("State", (int)States.Idle);
				} else if (transform.position.y > lastPos.y) {
					enemyAnim.SetInteger ("State", (int)States.UpIdle);
				}
			}


			lastPos = enemyTransform.position;




			//targetHeading = target.position - enemyTransform.position;
			//targetDirection = targetHeading.normalized;
			//enemyTransform.rotation = Quaternion.LookRotation (targetDirection);
			//enemyTransform.eulerAngles = new Vector3 (45, 0, 0);

			//enemyTransform.position += transform.up * speed * Time.deltaTime;
			//enemyTransform.position -= transform.right * speed * Time.deltaTime;

		}




	}

	IEnumerator WaitMove(float amount) {
		yield return new WaitForSeconds (amount);
		if (ran == 0) {
			enemyTransform.position += Vector3.left * speed * Time.deltaTime;
		} else if (ran == 1) {
			enemyTransform.position += Vector3.down * speed * Time.deltaTime;
		} else if (ran == 2) {
			enemyTransform.position += Vector3.right * speed * Time.deltaTime;
		} else {			
			enemyTransform.position += Vector3.up * speed * Time.deltaTime;
		}


	}

	IEnumerator WaitHit(float amount) {
		yield return new WaitForSeconds (amount);
	}

	public void takeDamage() {
		if (health >= 1.0f) {			
			health -= 1.0f;
			gameObject.GetComponent<AudioSource> ().clip = damaged;
			gameObject.GetComponent<AudioSource> ().Play ();
			StartCoroutine(WaitHit(1.0f));
			if (health < .5f) {
				alive = false;
				if (hasDrop == true) {
					DropItem ();
				}
				gameObject.GetComponent<AudioSource> ().clip = killed;
				gameObject.GetComponent<AudioSource> ().Play ();
				Destroy (this.gameObject);
			}
		} else if(health < 0.5f) {
			alive = false;
			//print ("I should be dead");
			if (hasDrop == true) {
				DropItem ();
			}
			gameObject.GetComponent<AudioSource> ().clip = killed;
			gameObject.GetComponent<AudioSource> ().Play ();
			Destroy(this.gameObject);
		}
	}

	void DropItem() {
		
		//Instantiate (drop, transform.position, Quaternion.identity);
		drop.transform.position = transform.position;
		drop.gameObject.SetActive (true);
	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			closeby = true;

			//enemyTransform.position += transform.right * speed * Time.deltaTime;
			//enemyTransform.position += transform.up * speed * Time.deltaTime;

		}
	}

	void OnTriggerExit2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			
			closeby = false;

		}
	}

	public void hitPlayer() {
		hit ();
	}



}
