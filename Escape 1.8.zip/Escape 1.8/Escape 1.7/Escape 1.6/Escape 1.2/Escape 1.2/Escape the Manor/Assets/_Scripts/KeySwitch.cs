﻿using UnityEngine;
using System.Collections;

public class KeySwitch : MonoBehaviour {
	public Sprite switchPressed;
	public Sprite switchUp;
	public bool pressed = false;


	// Use this for initialization
	void Start () {
		gameObject.GetComponent<SpriteRenderer> ().sprite = switchUp;
	}

	// Update is called once per frame
	void Update () {

	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.tag == "Player") {
			if (pressed == false) {
				
				gameObject.GetComponent<AudioSource> ().Play();
				gameObject.GetComponent<SpriteRenderer> ().sprite = switchPressed;
				pressed = true;
			}

			

		}
	}
}
