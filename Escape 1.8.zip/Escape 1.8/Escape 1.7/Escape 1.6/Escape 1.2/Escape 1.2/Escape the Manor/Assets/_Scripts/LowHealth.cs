﻿using UnityEngine;
using System.Collections;

public class LowHealth: MonoBehaviour {
	public PlayerScript play;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		if (play.hp < 1.5f) {
			gameObject.GetComponent<AudioSource> ().Play ();
		}
	}
}