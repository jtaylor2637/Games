//
//  ListItemsCommand.swift
//  StarterGame
//
//  Created by csu on 4/25/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//list command is functional to provide multiple options for the user to list information, list characters shows characters in the room, list items shows items in the room, list money shows player money held, list weight shows current weight of player, and list with no second word lists the player's inventory
class ListCommand : Command {
    override init() {
        super.init()
        self.name = "list"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() == true {
            if secondWord! == "items" || secondWord! == "room" {
                player.listRoomItems()
            } else if secondWord! == "characters" {
                player.listCharacters()
            } else if secondWord! == "enemies" {
                player.listEnemy()
            } else if secondWord! == "money" {
                player.listMoney()
            } else if secondWord! == "weight" {
                player.listWeight()
            
            } else {
                player.warningMessage("\nList What?")
            }
            
            
        } else {
            player.listItems()
        }
        return false
    }
}