//
//  GoCommand.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation

// go command is a subclass of the command class, it tells the player class to move a certain way
class GoCommand: Command {
    
    override init() {
        super.init()
        self.name = "go"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            if (secondWord! == "back") { //if second word is back, perform back command
                player.walkBack()
            } else {
                player.walkTo(secondWord!)
            }
            
        } else {
            player.warningMessage("\nGo Where? To go back to the previous room type 'go back'.")
        }
        return false
    }
}
