//
//  PickupCommand.swift
//  StarterGame
//
//  Created by csu on 4/21/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// pickup command allows player to pickup a item from the room and goes to their hand, you have to specify item
class PickupCommand: Command {
    
    override init() {
        super.init()
        self.name = "pickup"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.pickupItem(secondWord!)
            
        } else {
            player.warningMessage("\nPickup What?")
        }
        return false
    }
}