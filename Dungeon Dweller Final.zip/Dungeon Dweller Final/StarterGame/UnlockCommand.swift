//
//  UnlockCommand.swift
//  StarterGame
//
//  Created by csu on 4/21/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation


//allows player to unlock a door at a direction
class UnlockCommand: Command {
    
    override init() {
        super.init()
        self.name = "unlock"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.unlock(secondWord!)
            
        } else {
            player.warningMessage("\nUnlock What?")
        }
        return false
    }
}