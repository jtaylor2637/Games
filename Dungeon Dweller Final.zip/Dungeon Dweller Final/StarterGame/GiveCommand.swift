//
//  GiveCommand.swift
//  StarterGame
//
//  Created by csu on 4/25/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation

// allows the player to give items to characters in the game, requires three words to be successful, in order of give name itemname
class GiveCommand : Command {
    override init() {
        super.init()
        self.name = "give"
    }
    
    override func execute(player: Player) -> Bool {
        if hasThirdWord() && hasSecondWord() {
            player.giveItem(secondWord!, itemName: thirdWord!)
            
        } else if hasSecondWord(){
            player.warningMessage("\n Give \(secondWord!) What?")
        } else {
            player.warningMessage("\n Give Who?")
        }
        return false
    }

    
}