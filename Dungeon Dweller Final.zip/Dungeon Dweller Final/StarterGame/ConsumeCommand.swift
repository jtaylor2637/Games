//
//  ConsumeCommand.swift
//  StarterGame
//
//  Created by csu on 4/27/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows player to consume items that are consumable such as the potions
class ConsumeCommand : Command {
    override init() {
        super.init()
        self.name = "consume"
    }
    override func execute(player: Player) -> Bool {
        if hasSecondWord(){
            player.consume(secondWord!)
        } else {
            player.warningMessage("\n Consume What?")
        }
        return false
    }
    
}