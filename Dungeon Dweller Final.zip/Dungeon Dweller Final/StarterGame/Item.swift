//
//  Item.swift
//  StarterGame
//
//  Created by csu on 4/11/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// item class has name, weight, value
class Item : Consumables {
    var name : String
    var weight : float_t
    var value : integer_t
    var decorator : Item?
    
    convenience init() {
        self.init(name : "Nameless")
    }
    
    convenience init(name : String) {
        self.init(name : name, weight : 1.0)
    }
    
    convenience init(name : String, weight : float_t) {
        self.init(name : name, weight : weight, value : 1)
    }
    
    init (name : String, weight : float_t, value : integer_t) {
        self.name = name
        self.weight = weight
        self.value = value
    }
    
    func getValue() -> integer_t {
        if decorator != nil {
            return value + (decorator?.getValue())!
            
        } else {
            return value
        }
    }
    
    func getWeight() -> float_t {
        if decorator != nil {
            return weight + (decorator?.getWeight())!
            
        } else {
            return weight
        }
    }
    
    func setName(newname : String) {
        name = newname
    }
    
    func getName() -> String {
        if decorator != nil {
            
            return name
        } else {
            return name
        }
    }
    //sets sell value as 75% of face value
    func getSellValue() -> integer_t {
        var sellValue : float_t = float_t(self.getValue())
        sellValue *= 0.75
        return integer_t(sellValue)
    }
    
    
    
    func addDecorator(decorator : Item) {
        if(self.decorator != nil) {
            self.decorator!.addDecorator(decorator)
        } else {
            self.decorator = decorator
        }
    }
    
    
    func isBackpack() -> Bool {
        return false
    }
    
    func isContainer() -> Bool {
        return false
    }
    
    func isWeapon() -> Bool {
        return false
    }
    
    func isPotion() -> Bool {
        return false
    }
    
    func isConsumable() -> Bool {
        return false
    }
    
    func description() -> String {
        if decorator != nil {
            return "\(name) with weight \(self.getWeight()) and value \(self.getValue())"
        } else {
            return "\(name) with weight \(self.getWeight()) and value \(self.getValue())"
        }
        
    }
    
    


}