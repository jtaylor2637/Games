//
//  AskForItemCommand.swift
//  StarterGame
//
//  Created by csu on 4/25/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation


//allows the player to ask for items from a character, the second word is the item name you desire
class AskForItemCommand : Command {
    override init() {
        super.init()
        self.name = "askfor"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.askForItem(secondWord!)
        } else {
            player.warningMessage("\n Ask for What?")
        }
        return false
    }
}