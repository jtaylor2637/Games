//
//  LookCommand.swift
//  Dungeon Dweller
//
//  Created by csu on 5/2/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// does search commands but uses look as the first word
class LookCommand : Command {
    override init() {
        super.init()
        self.name = "look"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            if secondWord == "room" {
                player.search()
            } else {
                player.searchSomething(secondWord!)
            }
            
        } else {
            player.search()
        }
        return false
    }
}