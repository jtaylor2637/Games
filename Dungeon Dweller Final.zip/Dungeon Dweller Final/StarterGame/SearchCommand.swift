//
//  SearchCommand.swift
//  StarterGame
//
//  Created by csu on 4/25/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// the most used command in the game, it allows players to search the room if no second word is given, which provides a new description of the room, and if a second word is given, you search specific things in the room to possibly find items
class SearchCommand : Command {
    override init() {
        super.init()
        self.name = "search"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            if secondWord == "room" {
                player.search()
            } else {
                player.searchSomething(secondWord!)
            }
           
        } else {
            player.search()
        }
        return false
    }
}