//
//  AppDelegate.swift
//  StarterGame
//
//  Created by JMK Productions on 3/15/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Cocoa
//allows interaction between interface and game
@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!
    @IBOutlet weak var windowStats: NSWindow!
    @IBOutlet weak var Output: NSScrollView!
    @IBOutlet weak var statsOutput: NSScrollView!
    
    @IBOutlet weak var Command: NSTextField!
    var gameIO : GameOutput?
    var game : Game?
    var statsIO : GameOutput?
/*
    override init() {
        super.init()
    }
*/
    
    @IBAction func Command(sender: AnyObject) {
        if game!.execute(sender.stringValue) {
            game!.end()
        }
        Command.stringValue = ""
    }
    //launches base game and output screen
    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
        let tv : NSTextView = Output.documentView as! NSTextView
        tv.editable = false
        
        //let stats : NSTextView = statsOutput
        //stats.editable = false
        //stats.
        gameIO = GameOutput(newOutput: Output.documentView as! NSTextView)
        game = Game(gameIO: gameIO!)
        game!.start()
        Command.becomeFirstResponder()
    }
    //launches stat window when application is activated
    func applicationDidBecomeActive(notification: NSNotification) {
        
    
        // Insert code here to initialize your application
        //let tv : NSTextView = Output.documentView as! NSTextView
        //tv.editable = false
        
        let stats : NSTextView = statsOutput.documentView as! NSTextView
        stats.editable = false
        //stats.
        statsIO = GameOutput(newOutput: statsOutput.documentView as! NSTextView)
        //gameIO = GameOutput(newOutput: Output.documentView as! NSTextView)
        //game = Game(gameIO: gameIO!)
        //game!.start()
        //Command.becomeFirstResponder()
        //statsIO?.sendLine("Hello")
        //statsIO?.clear()
        game?.setStatIO(statsIO!)
        NSNotificationCenter.defaultCenter().postNotificationName("PlayerInitialStats", object: self)
        
    }
    
    
    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

