//
//  BackCommand.swift
//  StarterGame
//
//  Created by csu on 4/4/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows the player to walk back to the room they were at previously
class BackCommand : Command {
    
    override init() {
        super.init()
        self.name = "back"
    }
    
    
    override func execute(player: Player) -> Bool {
        
        if hasSecondWord() {
            player.warningMessage("\nI Cannot have second word \(secondWord)")
            
        } else {
            player.walkBack()
        }
        return false
    }
}