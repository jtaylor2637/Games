//
//  GameWorld.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//creates a singleton / shared instance of a world for the game to run, has all the rooms, enemies, npcs, and various items and intricacies of the dungeon
class GameWorld {
    var entrance : Room
    var exit : Room
    var trigger : Room
    var fromRoom : Room
    var toRoom : Room
    var toAlternate : Room
    var searchedRoom : Room?
    static var sharedInstance : GameWorld = GameWorld()
    static var savedTag : String = ""
    var roomsInWorld : [Room] = [Room]() //array of all rooms created
    var roomsDictionary : [integer_t : Room] = [integer_t : Room]() //dictionary of all rooms created
    var passageKey : Item = Item(name: "passagekey") //global key used to give to secret door once the door is created through the search event
    var allNPCList : [String : NonPlayableCharacter] = [String : NonPlayableCharacter]() //all the npc's in the game
    var allEnemyList : [String : Enemy] = [String : Enemy]() //all the enemies in the game

    

    
    private init() {
        entrance = Room()
        exit = entrance
        trigger = exit
        fromRoom = exit
        toRoom = fromRoom
        toAlternate = toRoom
        let rooms = self.createWorld()
        
        entrance = rooms["entrance"]! //start room of the game
        //all notifications the gameworld uses to interact with player
        NSNotificationCenter.defaultCenter().addObserver(self, selector : #selector(playerSearchedRoom(_ : )), name: "playerSearchRoom", object : nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector : #selector(playerSearchedItemInRoom(_ : )), name: "playerSearchItemInRoom", object : nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(playerConsumedSomething(_ :)), name: "playerConsumedSomething", object: nil)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(playerDidEnterRoom(_ :)), name: "playerDidEnterRoom", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(playerEnteredCommand), name: "playerEnteredCommand", object: nil)
       
        
        
        
    }
    // initializes all the rooms in the world, sets all the search descriptions and adds them to the room dictionary to be used for indexing later
    func createWorld() -> [String : Room] {
        
        let cell = Room(tag: "inside a small corner holding cell within a larger room filled with other holding cells. A cell door lies north of you", roomName : "cell")
        cell.setRoomSearchDescription("You notice after looking around the cell that one of the bricks in the wall is loose")
        roomsDictionary[0] = cell
        
        let cellCorridor = Room(tag: "in the corridor between the two rows of cells, a wooden door is to your east", roomName: "cell corridor")
        cellCorridor.setRoomSearchDescription("There is something shiny on the wall closest to the door")
        roomsDictionary[1] = cellCorridor
        
        let guardQuarters = Room(tag: "inside the dungeon guards quarters. Stairs lie east of you, and a door lies to your south", roomName: "Guard Quarters")
        guardQuarters.setRoomSearchDescription("There are a few straw beds and personal items of the guards strewn across the room")
        roomsDictionary[2] = guardQuarters
        
        let cellar = Room(tag: "in the guard quarter's pantry, there is a trap door in the floor close to the east wall", roomName: "cellar")
        cellar.setRoomSearchDescription("The pantry contains barrels that are labeled with different foods")
        roomsDictionary[3] = cellar
        
        let westHallway = Room(tag: "in the hallway that the dungeon stairs lead up to. There is a door to your north and south. The hallway continues further to the east", roomName: "west hallway")
        westHallway.setRoomSearchDescription("The light in the hallway blinds you as you emerge from the lower floor, there are a few uninteresting landscape paintings hanging on the walls")
        roomsDictionary[4] = westHallway
        
        let sittingRoom = Room(tag: "in a nice sitting room, the furniture looks like it's out of your price range", roomName: "sitting room")
        sittingRoom.setRoomSearchDescription("The room is elaborately decorated with a few sitting chairs, a very luxurious and comfortable couch, and a table in between the sitting chairs, a merchant is sitting behind a desk in the corner of the room")
        roomsDictionary[5] = sittingRoom
        
        let trainingRoom = Room(tag: "in a large training room filled with training dummies, there is a door in the south corner of the room", roomName: "training room")
        trainingRoom.setRoomSearchDescription("There are several training dummies throughout the room, one of them looks to have been cleaved in half by a large blade")
        roomsDictionary[6] = trainingRoom
        
        let armory = Room(tag: "in a storage room containing the remnants of what was a well stocked armory", roomName: "armory")
        armory.setRoomSearchDescription("There is a weapon rack in the center of the room, a blacksmith has taken over the forge in the far corner of the room")
        roomsDictionary[7] = armory
        
        let balcony = Room(tag: "in the main balcony entrance to the castle. Stairs to the north lead down to the foyer of the ground floor, a grand staircase to the south goes up to a set of large double doors, and the hallways join here from the east and west", roomName: "balcony")
        balcony.setRoomSearchDescription("Looking over the side of the balcony, there seems to be a high drop. Jumping wouldn't be wise")
        roomsDictionary[8] = balcony
        
        let throneEntrance = Room(tag: "at the top of the grand staircase the balcony led up to, a large set of doors lies south of you", roomName: "throne entrance")
        throneEntrance.setRoomSearchDescription("Looking around the vicinity, you notice two life size bearded armored statues, one on each side of the door, they are each wielding a large two-handed greataxe and seem to stare you down as you approach")
        roomsDictionary[9] = throneEntrance
        
        let throneRoom = Room(tag: "inside of an expansive space, there is a red carpet lining the center of the room, which leads to a massive golden throne", roomName: "throneRoom")
        throneRoom.setRoomSearchDescription("The throne looks fit for a king, but you also notice a skull on each side of the throne itself")
        roomsDictionary[10] = throneRoom
        
        let foyer = Room(tag: "in the foyer that the balcony stairs led down to, the main castle doors are to your north", roomName: "foyer")
        foyer.setRoomSearchDescription("You find an open space with a fountain and exquisitely carved prime examples of marble nude statuary")
        roomsDictionary[11] = foyer
        
        let eastHallway = Room(tag: "in a brightly lit hallway. Doors lie to the north and south", roomName: "east hallway")
        eastHallway.setRoomSearchDescription("More uninteresting landscape paintings are hanging on the walls")
        roomsDictionary[12] = eastHallway
        
        let ballroom = Room(tag: "in the royal ballroom, a small door is nestled in the east corner", roomName: "ballroom")
        ballroom.setRoomSearchDescription("Crystal chandeliers light up the room and a dance floor takes up the center of the room")
        roomsDictionary[13] = ballroom
        
        let closet = Room(tag: "in a small storage closet, which you decided to go looking in for some reason", roomName: "closet")
        closet.setRoomSearchDescription("there is a small wardrobe against the wall")
        roomsDictionary[14] = closet
        
        let diningRoom = Room(tag: "in the royal dining room. A door is at the southern end of the room", roomName: "dining room")
        diningRoom.setRoomSearchDescription("A long oak table takes up a majority of the room, a massive feast is prepared on the table, gold and silver utensils are laid out in front of the chairs, a very large rotisserie chicken is the centerpiece of the feast")
        roomsDictionary[15] = diningRoom
        
        let kitchen = Room(tag: "in the royal dining room's kitchen", roomName: "kitchen")
        kitchen.setRoomSearchDescription("Cooking utensils are scattered across the room, there is a set of various knives on the counter")
        roomsDictionary[16] = kitchen
        
        let pantry = Room(tag: "in the kitchen pantry", roomName: "pantry")
        pantry.setRoomSearchDescription("Various ingredients for cooking are stored in sacks, there are several shelves lining the room")
        roomsDictionary[17] = pantry
        
        let secretPassage = Room(tag: "in a small tunnel which leads south", roomName: "secret passage")
        secretPassage.setRoomSearchDescription("This appears to be an old service entrance to the castle, it looks like it hasn't been used in some time")
        roomsDictionary[18] = secretPassage
        
        let outside = Room(tag: "in a dense forest behind the castle", roomName: "outside")
        outside.setRoomSearchDescription("it is pretty dark and scary out here, but at least you're not trapped in that castle")
        roomsDictionary[19] = outside
        
        
        let teleporterRoom = Room(tag: "in a very small room, it has a magical essence to it", roomName: "teleporter")
        teleporterRoom.setRoomSearchDescription("You shudder at the chills the room gives you")
        roomsDictionary[20] = teleporterRoom
        
        let fakeOutside = Room(tag: "in a place you shouldn't be", roomName: "fake outside")
        fakeOutside.setRoomSearchDescription("You broke the 4th wall, how'd you get here?")
        
        for thisRoom in roomsDictionary.values {
            roomsInWorld.append(thisRoom)
            
        }
        
        
        //all the doors are created and it creates the connections between rooms, and all the doors are closed and locked appropriately
        let playerCellDoor = connectRooms(cellCorridor, room2: cell, exitName1: "south", exitName2 : "north")
        let cellLock = CellLock()
        playerCellDoor.lockType = cellLock
        
        let cellKey : Item = Item(name: "cellKey")
        playerCellDoor.setOriginalKey(cellKey)
        playerCellDoor.setInsertedKey()
        
        playerCellDoor.close()
        playerCellDoor.lock()
        
        let jailDoor = connectRooms(guardQuarters, room2: cellCorridor, exitName1: "west", exitName2: "east")
        let jailLock = RegularLock()
        jailDoor.lockType = jailLock
        jailDoor.close()
        jailDoor.lock()
        
        
        let cellarDoor = connectRooms(cellar, room2: guardQuarters, exitName1: "north", exitName2: "south")
        cellarDoor.close()
        
        let teleporterDoor = connectRooms(teleporterRoom, room2: cellar, exitName1: "none", exitName2: "east")
        teleporterDoor.close()
        
        let quarterStairs = connectRooms(westHallway, room2: guardQuarters, exitName1: "west", exitName2: "east")
        
        let sittingRoomDoor = connectRooms(sittingRoom, room2: westHallway, exitName1 : "south", exitName2: "north")
        sittingRoomDoor.close()
        
        let trainingRoomDoor = connectRooms(trainingRoom, room2: westHallway, exitName1 : "north", exitName2: "south")
        let trainingLock = RegularLock()
        trainingRoomDoor.lockType = trainingLock
        let trainingRoomKey : Item = Item(name: "trainingroomkey")
        trainingRoomDoor.setOriginalKey(trainingRoomKey)
        trainingRoomDoor.setInsertedKey()
        trainingRoomDoor.close()
        trainingRoomDoor.lock()
        
        let armoryDoor = connectRooms(armory, room2: trainingRoom, exitName1: "north", exitName2: "south")
        let armoryLock = RegularLock()
        armoryDoor.lockType = armoryLock
        let armoryKey : Item = Item(name: "armorykey")
        armoryDoor.setOriginalKey(armoryKey)
        armoryDoor.setInsertedKey()
        armoryDoor.close()
        armoryDoor.lock()
        
        
        let balconyDoorWest = connectRooms(balcony, room2 : westHallway, exitName1: "west", exitName2: "east")
        
        let balconyDownStairs = connectRooms(foyer, room2: balcony, exitName1: "south", exitName2: "north")
        
        let balconyUpStairs = connectRooms(throneEntrance, room2: balcony, exitName1: "north", exitName2: "south")
        
        let throneRoomDoor = connectRooms(throneRoom, room2: throneEntrance, exitName1: "north", exitName2: "south")
        let throneLock = RegularLock()
        throneRoomDoor.lockType = throneLock
        let throneKey : Item = Item(name: "throneroomkey")
        throneRoomDoor.setOriginalKey(throneKey)
        throneRoomDoor.setInsertedKey()
        throneRoomDoor.close()
        throneRoomDoor.lock()
        
        let balconyDoorEast = connectRooms(eastHallway, room2: balcony, exitName1: "west", exitName2: "east")
        
        let mainDoor = connectRooms(fakeOutside, room2: foyer, exitName1: "south", exitName2: "north")
        let mainDoorLock = RegularLock()
        mainDoor.lockType = mainDoorLock
        mainDoor.close()
        mainDoor.lock()
        
        let ballroomDoor = connectRooms(ballroom, room2: eastHallway, exitName1: "south", exitName2: "north")
        ballroomDoor.close()
        
        let closetDoor = connectRooms(closet, room2: ballroom, exitName1: "west", exitName2: "east")
        let closetLock = RegularLock()
        closetDoor.lockType = closetLock
        let closetKey : Item = Item(name: "closetkey")
        closetDoor.setOriginalKey(closetKey)
        closetDoor.setInsertedKey()
        closetDoor.close()
        closetDoor.lock()
        
        let diningRoomDoor = connectRooms(diningRoom, room2: eastHallway, exitName1: "north", exitName2: "south")
        diningRoomDoor.close()
        
        let kitchenDoor = connectRooms(kitchen, room2: diningRoom, exitName1: "north", exitName2: "south")
        kitchenDoor.close()
        
        let pantryDoor = connectRooms(pantry, room2: kitchen, exitName1: "east", exitName2: "west")
        pantryDoor.close()
        
        let exitDoor = connectRooms(outside, room2: secretPassage, exitName1: "north", exitName2: "south")
        
        
        
        
        
        var output : [String : Room] = [String : Room]()
        output["entrance"] = cell //sets start room for player
        
        
        //creates items for merchant to hold
        let plasmasabser = Weapon(name: "plasmasaber", weight: 3.5, value : 160, thisDamage: 10, thisdurability: 6.0)
        let gun = Weapon(name: "machinegun", weight: 8.7, value: 225, thisDamage: 20, thisdurability: 2.0)
        let healthpotion = Potion(name: "healthpotion", weight: 1.0, value: 30, attribute: "healing", effect: 0)
        let strpotion = Potion(name: "strengthpotion", weight: 1.0, value: 30, attribute: "strength", effect: 2)
        let dmgpotion = Potion(name: "damagepotion", weight: 1.0, value: 30, attribute: "damage", effect: 3)
        let ring = Item(name: "goldenring", weight: 0.1, value: 15)
        let crystal : Item = Item(name: "ruby", weight: 1.0, value : 25)
        ring.addDecorator(crystal)
        
        let greataxe = Weapon(name: "greataxeofgreed", weight: 15.0, value: 600, thisDamage: 30, thisdurability: 10.0)
        //creates merchant
        let merchant = NonPlayableCharacter(npcName: "Zil", npcOccupation : "Merchant")
        
        
        
        //adds merchant to room and sets all of his necessary information, storing his items etc.
        sittingRoom.addNPC(merchant)
        merchant.setResponse("Greetings dungeon dweller, Would you like to buy something to help you on your journey?")
        merchant.setWantedItem("weaponvoucher")
        merchant.setHeld(greataxe)
        
        merchant.storeInPack(plasmasabser)
        merchant.storeInPack(healthpotion)
        merchant.storeInPack(strpotion)
        merchant.storeInPack(dmgpotion)
        merchant.storeInPack(gun)
        merchant.addNotifications()
        merchant.conditionNotMet()
        
        //creates the blacksmith and all of his information
        let blacksmith = NonPlayableCharacter(npcName: "Hugo", npcOccupation : "Blacksmith")
        armory.addNPC(blacksmith)
        blacksmith.setResponse("I see you made your way to my forge, do you need anything repaired?")
        //blacksmith.setPath([7,7,7,7])
        blacksmith.conditionNotMet()
        blacksmith.addNotifications()
        
        //creates the roamer which moves throughout the game world
        let theRoamer = NonPlayableCharacter(npcName: "Roamer", npcOccupation: "eternally condemned")
        closet.addNPC(theRoamer)
        theRoamer.setResponse("I've been cursed to roam this castle forever, hopefully you do not end up with the same fate")
        theRoamer.setPath([14,1,2,3,2,4,5,4,6,7,6,4,8,11,8,9,10,9,8,12,13,14,13,12,15,16,17,16,15,12,13,14,13,12,8,9,10,9,8,11,8,4,6,7,6,4,5,4,2,3,2,1,14])
        
        //creates the cell guardian and all of his drops
        let guardian = Enemy(name: "Cell Guard", health: 10, attackDmg: 0)
        let guardsSword = Weapon(name: "guardsword", weight: 2.0, value: 5, thisDamage: 2, thisdurability: 3.0)
        guardian.addItem(ring)
        guardian.addItem(trainingRoomKey)
        guardian.setHeld(guardsSword)
        guardQuarters.addEnemy(guardian)
        
        //creates the armored dummy and all of his drops
        let armoredDummy = Enemy(name: "Animated Dummy", health: 15, attackDmg: 0)
        let trainingStaff = Weapon(name: "trainingstaff", weight: 4.0, value: 5, thisDamage: 4, thisdurability: 3.0)
        let strup = Potion(name: "strengthup", weight: 1.0, value: 30, attribute: "strength", effect: 2)
        let anotherhp = Potion(name: "fillhp", weight: 1.0, value: 30, attribute: "healing", effect: 0)
        armoredDummy.addItem(strup)
        armoredDummy.addItem(anotherhp)
        armoredDummy.addItem(armoryKey)
        armoredDummy.setHeld(trainingStaff)
        trainingRoom.addEnemy(armoredDummy)
        
        //creates the knight and all of his drops
        let knight = Enemy(name: "Loyal Knight Nick", health: 30, attackDmg: 3)
        let knightSword = Weapon(name: "knightsword", weight: 5.0, value: 15, thisDamage: 5, thisdurability: 5.0)
        let restore = Potion(name: "restore", weight: 1.0, value: 30, attribute: "healing", effect: 0)
        let damgpot = Potion(name: "damageup", weight: 1.0, value: 30, attribute: "damage", effect: 3)
        knight.addItem(damgpot)
        knight.addItem(restore)
        knight.addItem(throneKey)
        knight.setHeld(knightSword)
        balcony.addEnemy(knight)
        
        //creates the fencer and all of his drops
        let fencer = Enemy(name: "Fearless Fencer", health: 50, attackDmg: 1)
        let rapier = Weapon(name: "rapier", weight: 7.0, value: 20, thisDamage: 9, thisdurability: 8.0)
        let hprestore = Potion(name: "hprestore", weight: 1.0, value: 30, attribute: "healing", effect: 0)
        fencer.addItem(closetKey)
        fencer.addItem(hprestore)
        fencer.setHeld(rapier)
        ballroom.addEnemy(fencer)
        
        //creates the final boss King Obando, he's the best boss ever!
        let kingObando = Enemy(name: "King Obando: Ruler of the Game World", health: 90, attackDmg: 6)
        let obandosGreataxe = Weapon(name: "kingsgreataxe", weight: 45.0, value: 300, thisDamage: 12, thisdurability: 1000.0)
        kingObando.addItem(passageKey)        
        kingObando.setHeld(obandosGreataxe)
        throneRoom.addEnemy(kingObando)
        
        
        //adds all the npcs to the dictionary and enemies to their dictionary
        addtoEveryNPCList(merchant)
        addtoEveryNPCList(blacksmith)
        addtoEveryNPCList(theRoamer)
        addtoEveryEnemyList(guardian)
        addtoEveryEnemyList(armoredDummy)
        addtoEveryEnemyList(fencer)
        addtoEveryEnemyList(knight)
        addtoEveryEnemyList(kingObando)
        
        
        //outside.item = Container(name: "Chest", weight : 2.0, value: 1.0)
        //let staff = Item(name: "Staff", weight: 2.3, value: 10.7)
        //(outside.item as! Container).store(staff)
        //let crystal : Item = Item(name: "Ruby", weight: 1.1, value : 15.0)
        //staff.addDecorator(crystal)
        //let shovel : Item = Item(name: "Shovel", weight: 1.0, value: 0.5)
        //(outside.item as! Container).store(shovel)
        
        return output //returns the game world start point
        
        
        
    }
    
    //adds character to npc list
    func addtoEveryNPCList(character : NonPlayableCharacter) {
        allNPCList[character.getName()] = character
    }
    
    //adds enemy to enemy list
    func addtoEveryEnemyList(enemy : Enemy) {
        allEnemyList[enemy.getName()] = enemy
    }
    
    //produces the movement necessary for all npcs when the player triggers this event, and the npcs also trigger a notification to alert player of their presence
    func iteratePath() {
        for chars in allNPCList.values {
            if chars.hasPath() == true {
                //have a path array of integers which correspond to room numbers / indexes in the room array
                //get the path, remove the first index to be the current room, and then look at new head to be next room, add current room to end of path so 
                //that it creates a queue to repeat the movement
                var charPath : [integer_t] = chars.getPath()
                var current : integer_t = charPath.removeAtIndex(0)
                var next : integer_t = charPath[0]
                charPath.append(current)
                chars.setPath(charPath)
                
                //the rooms the npc was in and will go to
                var npcFromRoom : Room = roomsDictionary[current]!
                var npcToRoom : Room = roomsDictionary[next]!
                let removedNPC : NonPlayableCharacter? = npcFromRoom.removeNPC(chars.getName())! //remove npc from original room
                
                if removedNPC == nil {
                    //do something
                } else {
                    //post npc left room
                    var testDictionary : [String : Room] = [String : Room]()
                    testDictionary["changedRoom"] = npcToRoom
                    var otherDictionary : [String : Room] = [String : Room]()
                    otherDictionary["changedRoom"] = npcFromRoom
                    //post notification if npc entered room with player
                    NSNotificationCenter.defaultCenter().postNotificationName("NPCEnteredPlayerRoom", object: removedNPC, userInfo: testDictionary)
                    
                    
                    //adds npc to the next room in path
                    npcToRoom.addNPC(removedNPC!)
                    //post npc left room of player
                    NSNotificationCenter.defaultCenter().postNotificationName("NPCLeftPlayerRoom", object: removedNPC, userInfo: otherDictionary)
                    
                    
                }
                
            }
            
        }

        
    }
    
    //notification handled event that triggers everytime player enters a command
    @objc func playerEnteredCommand(notification : NSNotification) {
        let player : Player = notification.object as! Player
        
        //if enemy in room with player, attack first
        for enemy in allEnemyList.values {
            if player.currentRoom.hasThisEnemy(enemy.getName()) {
                enemy.attackFirst()
            }
        }
        
        
    }
    
    
    
        
    
    
    //notification handled event for searching the room, it obtains the searched room and changes the description to fit the number of times the room was searched, applies to all rooms in game
    @objc func playerSearchedRoom(notification : NSNotification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : Room]
        let searchedRoom : Room = userInfo["searchedRoom"]!
        
        if searchedRoom === roomsDictionary[0] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                if searchedRoom.hasThisItem("lockpick") == true {
                    searchedRoom.setRoomSearchDescription("The makeshift lockpick is in the cell")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                } else {
                    searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                }
            }

        } else if searchedRoom === roomsDictionary[1] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                if searchedRoom.hasThisItem("corridorkey") == true {
                    searchedRoom.setRoomSearchDescription("The key is in the room")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                } else {
                    searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                }
            }
            
        } else if searchedRoom === roomsDictionary[3] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
        } else if searchedRoom === roomsDictionary[5] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
        
            
        } else if searchedRoom === roomsDictionary[6] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
        } else if searchedRoom === roomsDictionary[7] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
        } else if searchedRoom === roomsDictionary[14] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
        } else if searchedRoom === roomsDictionary[15] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
        } else if searchedRoom === roomsDictionary[16] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
            
        } else if searchedRoom === roomsDictionary[17] {
            if searchedRoom.getSearchCount() == 0 {
                player.outputMessage(searchedRoom.getSearchDescription()!)
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing in the room to search for")
                player.outputMessage(searchedRoom.getSearchDescription()!)
            }
        
        
        } else {
            player.outputMessage(searchedRoom.getSearchDescription()!)
        }
        
            
    }
    //notification handled event that updates the room's description whenever the player searches the correct item in the room, to save the progress of the rooms
    @objc func playerSearchedItemInRoom(notification : NSNotification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : Room]
        let searchedRoom : Room = userInfo["searchedRoom"]!
        
        //does the lockpick creation for the cell
        if searchedRoom === roomsDictionary[0] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You manage to remove the brick with some effort, in the cavity is a makeshift lockpick")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                let lockpick : Item = Item(name: "lockpick")
                searchedRoom.addItem(lockpick)
                let exit : Door = searchedRoom.getExit("north")!
                exit.setOriginalKey(lockpick)
                exit.setInsertedKey()
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                if searchedRoom.hasThisItem("lockpick") == true {
                    searchedRoom.setRoomSearchDescription("The makeshift lockpick is in the cell")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                } else {
                    searchedRoom.setRoomSearchDescription("There is nothing left there to search")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                }
            }
            //does the key creation for the corridor
        } else if searchedRoom === roomsDictionary[1] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You notice that there is a key hanging on a nail on the wall")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
                let corridorKey : Item = Item(name: "corridorkey")
                searchedRoom.addItem(corridorKey)
                let exit : Door = searchedRoom.getExit("east")!
                exit.setOriginalKey(corridorKey)
                exit.setInsertedKey()
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                if searchedRoom.hasThisItem("corridorkey") == true {
                    searchedRoom.setRoomSearchDescription("The key is in the room")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                } else {
                    searchedRoom.setRoomSearchDescription("There is nothing left there to search")
                    player.outputMessage(searchedRoom.getSearchDescription()!)
                }
                
            }
            //does the the creation of cellar items
        } else if searchedRoom === roomsDictionary[3] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You manage to find a potion, a puny rusted dagger, a health potion, and ten gold pieces")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                let hpPot : Potion = Potion(name: "hppotion", weight: 1.5, value: 15, attribute: "healing", effect: 1)
                let rustyDagger : Weapon = Weapon(name: "rustydagger", weight: 0.5, value: 5, thisDamage: 1, thisdurability: 1.0)
                player.increaseMoney(10)
                searchedRoom.addItem(hpPot)
                searchedRoom.addItem(rustyDagger)
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search, don't be greedy")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
            
            //does the creation of sitting room items
        } else if searchedRoom === roomsDictionary[5] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You manage to find a vial filled with a mysterious dark liquid in it, who knows what it does, you also find 25 gold pieces throughout the couch cushions")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
                let mysteriousPotion : Potion = Potion(name: "mysterypotion", weight: 0.5, value: 0, attribute: "unknown", effect: 0)
                player.increaseMoney(25)
                
                searchedRoom.addItem(mysteriousPotion)
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search, be careful with that liquid")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
        
            //does creation of training room items
        } else if searchedRoom === roomsDictionary[6] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You manage to find a dagger wedged into the remaining half of the dummy's armpit, the dagger is razor sharp and has golden inlays on the blade, it looks like it could slice a man's throat with little effort")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
                let sharpDagger : Weapon = Weapon(name: "assassinsdagger", weight: 1.5, value: 25, thisDamage: 6, thisdurability: 2.5)
                
                
                searchedRoom.addItem(sharpDagger)
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search, nice find though!")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
            //does the creation of armory items
        } else if searchedRoom === roomsDictionary[7] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You manage to find several potions, a small pouch containing 15 gold, and an old dull but durable training sword remaining in the room")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
                let trainingSword : Weapon = Weapon(name: "trainingsword", weight: 3.0, value: 5, thisDamage: 3, thisdurability: 8.0)
                let strPot : Potion = Potion(name: "strengthpotion", weight: 1.5, value: 15, attribute: "strength", effect: 2)
                let defPot : Potion = Potion(name: "defensepotion", weight: 1.5, value: 15, attribute: "defense", effect: 2)
                
                player.increaseMoney(15)
                
                searchedRoom.addItem(trainingSword)
                searchedRoom.addItem(strPot)
                searchedRoom.addItem(defPot)
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search, sadly there are no more weapons here for you")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
            //does closet item creation
        } else if searchedRoom === roomsDictionary[14] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You rummage through the wardrobe to find various outfits, in the pocket of one of them, you find a piece of paper which appears to be a voucher for a free axe from a merchant, and about 50 gold someone left in their pockets, nice score!")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
                
                
                let voucher : Item = Item(name: "weaponvoucher", weight: 0.2, value: 0)
                
                player.increaseMoney(50)
                searchedRoom.addItem(voucher)
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search, stop going through old clothes")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
        //does dining room item creation
        } else if searchedRoom === roomsDictionary[15] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You tear open the large chicken, and you find a health up potion, what's that doing there?")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
                
                
                let healthUpPot : Potion = Potion(name: "maxhealthpotion", weight: 1.5, value: 15, attribute: "health", effect: 10)
                
                
                searchedRoom.addItem(healthUpPot)
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search, you must really like tearing up other people's food")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
            //does kitchen item creation
        } else if searchedRoom === roomsDictionary[16] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You search the knife set, and you find a large meat cleaver, a small butter knife, and a large battle axe, what's that doing in there?")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
                
                
                let meatCleaver : Weapon = Weapon(name: "meatcleaver", weight: 2.0, value: 20, thisDamage: 5, thisdurability: 5.0)
                let butterKnife : Weapon = Weapon(name: "butterknife", weight: 1.0, value: 60, thisDamage: 30, thisdurability: 1.0)
                let battleAxe : Weapon = Weapon(name: "battleaxe", weight: 6.0, value: 30, thisDamage: 12, thisdurability: 6.0)
                
                
                searchedRoom.addItem(meatCleaver)
                searchedRoom.addItem(butterKnife)
                searchedRoom.addItem(battleAxe)
                searchedRoom.increaseSearchCount()
                player.outputMessage(searchedRoom.getItemList())
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search, you don't need anymore kitchen knives")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
            //creates the door between the pantry and the exit tunnel when searched, and also locks it using the passage key which is on the boss
        } else if searchedRoom === roomsDictionary[17] {
            if searchedRoom.getSearchCount() == 0 {
                searchedRoom.setRoomSearchDescription("You search the shelves, and discover a hidden door behind the southern most shelf")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                let hiddenDoor : Door = connectRooms(roomsDictionary[18]!, room2: roomsDictionary[17]!, exitName1: "north", exitName2: "south")
                let passageLock = RegularLock()
                hiddenDoor.lockType = passageLock
                hiddenDoor.setOriginalKey(passageKey)
                hiddenDoor.setInsertedKey()
                hiddenDoor.close()
                hiddenDoor.lock()
                searchedRoom.increaseSearchCount()
                
            } else {
                searchedRoom.setRoomSearchDescription("There is nothing left there to search")
                player.outputMessage(searchedRoom.getSearchDescription()!)
                
            }
        
        } else {
            player.outputMessage("\nThere is nothing else interesting about the room")
        }
        
        
    }
    //notification handled event which triggers when player consumes an item, modifies player stats according to the effects of the item consumed
    @objc func playerConsumedSomething(notification : NSNotification) {
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : Potion]
        let potion = userInfo["potion"]
        let potionAttr = potion!.getAttribute()
        let potionEffect = potion!.getEffect()
        
        if potionAttr == "health" {
            player.increaseHealth(potionEffect)
            player.outputMessage("\nYou consumed a \(potionAttr) potion. Your health is now \(player.getHealth())")
            if player.held?.getName() == potion?.getName() {
                player.takeFromHand()
            } else {
                player.takeFromPack((potion?.getName())!)
            }
        } else if potionAttr == "strength" {
            player.increaseStr(potionEffect)
            player.outputMessage("\nYou consumed a \(potionAttr) potion. Your strength is now \(player.getMyStr())")
            if player.held?.getName() == potion?.getName() {
                player.takeFromHand()
            } else {
                player.takeFromPack((potion?.getName())!)
            }
        } else if potionAttr == "damage" {
            player.increaseMyBaseDamage(potionEffect)
            player.outputMessage("\nYou consumed a \(potionAttr) potion. Your base damage is now \(player.getMyBaseDamage())")
            if player.held?.getName() == potion?.getName() {
                player.takeFromHand()
            } else {
                player.takeFromPack((potion?.getName())!)
            }
        } else if potionAttr == "defense" {
            player.increaseDef(potionEffect)
            player.outputMessage("\nYou consumed a \(potionAttr) potion. Your defense is now \(player.getMyDef())")
            if player.held?.getName() == potion?.getName() {
                player.takeFromHand()
            } else {
                player.takeFromPack((potion?.getName())!)
            }
        } else if potionAttr == "healing" {
            player.restoreHealth()
            player.outputMessage("\nYou consumed a \(potionAttr) potion. Your health is now \(player.getTotalHealth())")
            player.changedMyStats()
            if player.held?.getName() == potion?.getName() {
                player.takeFromHand()
            } else {
                player.takeFromPack((potion?.getName())!)
            }
        } else {
            player.warningMessage("\nCongrats! You consumed a useless potion")
            if player.held?.getName() == potion?.getName() {
                player.takeFromHand()
            } else {
                player.takeFromPack((potion?.getName())!)
            }
        }
        
        
        
    }

    
    //notification handled event when player enters a room, iterates the path of all npcs in the game, and if there is an enemy in the room, they attack the player via notification, and if the room you entered is the teleporter room, you get teleported to a random room, if player entered end game room, end the game via notification
    @objc func playerDidEnterRoom(notifcation : NSNotification) {
        let player : Player = notifcation.object as! Player
        let userInfo = notifcation.userInfo as! [String : Room]
        let enteredroom = userInfo["enteredRoom"]
        
        if enteredroom === roomsDictionary[20] {
            while player.roomStack.isEmpty() != true {
                player.roomStack.pop()
            }
            var roomNum = Int(arc4random_uniform(UInt32(18)))
            player.outputMessage("\n\nYou feel a mysterious force whisp you away")
            player.currentRoom = roomsInWorld[roomNum]
            player.outputMessage("\n\n \(player.currentRoom.description())")
        } else if enteredroom === roomsDictionary[19] {
            NSNotificationCenter.defaultCenter().postNotificationName("EndTheGame", object: self)
        }
        
        for enemy in allEnemyList.values {
            if player.currentRoom.hasThisEnemy(enemy.getName()) {
                player.warningMessage("\n\nThe \(enemy.getName()) notices you as you enter the room, and prepares to attack you \n")
                enemy.attackFirst()
            }
        }
        
        iteratePath()
            
    }
        
    //@objc func playerDidLeaveRoom(notification : NSNotification) {
            //let room : Room = notification.object as! Room
            /*if room === toRoom {
                fromRoom.setExit("secret", room: nil)
                toRoom.setExit("secret", room: nil)
            }*/
    
            
        //}
    
    
    
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
 
    
}
