//
//  DescribeCommand.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// gets the item's description specified in the second word
class DescribeCommand : Command {
    override init() {
        super.init()
        self.name = "describe"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.describe(secondWord!)
        } else {
            player.warningMessage("\nDescribe What?")
        }
        return false
    }
}