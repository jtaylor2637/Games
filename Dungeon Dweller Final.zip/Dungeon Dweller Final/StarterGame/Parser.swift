//
//  Parser.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//parser parses the string commands entered from the user and removes all of the white spaces from the command input
class Parser {
    var commands : CommandWords
    
    init(newCommands : CommandWords) {
        commands = newCommands
    }
    
    func parseCommand(commandString : String) -> Command? {
        
        var command : Command? = commands.get("")
        //let words = commandString.componentsSeparatedByString(" ") if parser breaks use this again and delete while loop
        var words = commandString.componentsSeparatedByCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        var index : Int? = words.indexOf("")
        while (index != nil) {
            words.removeAtIndex(index!)
            index = words.indexOf("")
        }
        if words.count > 0 {
            command = commands.get(words[0])
            if command != nil {
                if words.count > 2 {
                    if words[2] != "" && words[1] != "" {
                        command?.thirdWord = words[2]
                        command?.secondWord = words[1]
                    } else {
                        command?.thirdWord = nil
                        command?.secondWord = nil
                    }
                } else if words.count > 1 {
                    if words[1] != "" {
                        command?.secondWord = words[1]
                    } else {
                        command?.thirdWord = nil
                        command?.secondWord = nil
                    }
                
                } else {
                    command?.secondWord = nil
                    command?.thirdWord = nil
                }
            }
        }
        
        return command
    }
    
    func description() -> String {
        return commands.description()
    }
}

