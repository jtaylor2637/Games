//
//  RepairCommand.swift
//  StarterGame
//
//  Created by csu on 4/29/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows the user to repair their weapons when they are with the blacksmith, the second word is the item you want to repair
class RepairCommand : Command {
    override init() {
        super.init()
        self.name = "repair"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.repair(secondWord!)
        } else {
            player.warningMessage("\n Repair What?")
        }
        return false
    }
}