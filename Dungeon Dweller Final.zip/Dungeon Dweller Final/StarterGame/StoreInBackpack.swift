//
//  StoreInBackpack.swift
//  StarterGame
//
//  Created by JMK Productions on 3/17/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// allows player to store items either from their hand or from the room to their backpack
class StoreInBackpack: Command {
    
    override init() {
        super.init()
        self.name = "store"
    }
    //if you use a second word it searches backpack for item, otherwise just typing store, puts held item in backpack
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.storeFromRoom(secondWord!)
            
        } else {
            player.storeFromHand()
        }
        return false
    }
}
