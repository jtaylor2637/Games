//
//  Player.swift
//  StarterGame
//
//  Created by JMK Productions on 3/16/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
import Cocoa



//stack used to keep rooms the player visited so that they can use go back command
struct Stack<Element> {
    var items = [Element]()
    mutating func push(item: Element) {
        items.append(item)
    }
    mutating func pop() -> Element {
        return items.removeLast()
    }
    mutating func isEmpty() -> Bool {
        return items.isEmpty
    }
}


//player class which is used to play the game (duh), has a room stack, the output it puts on the main screen, an item held, a backpack, stats, and a money pouch
class Player {
    var roomStack = Stack<Room>()
    var currentRoom : Room
    var io : GameOutput
    var held : Item?
    var health : integer_t = 18
    var playerBaseDmg : integer_t = 1
    
    var playerStrength : integer_t = 1
    var playerDefense : integer_t = 1
    var totalHealth : integer_t = 20
    var totalDamage : integer_t = 1
    var totalStrength : integer_t = 1
    var totalDefense : integer_t = 1
    var backpack : Backpack = Backpack(name: "Standard Backpack", weight: 0.0, value: 0, limit : 20.0)
    var moneyPouch : MoneyPouch = MoneyPouch(name: "Money Pouch", contains: 0)
    
    init(room : Room, output : GameOutput) {
        currentRoom = room
        io = output
       
        
    }
    //lists the player's current weight
    func listWeight() {
        outputMessage("\nCurrent Weight: \(backpack.getWeight()) / \(backpack.getWeightLimit())")
    }
    //lists the player's current stats

    func getStats() {
        outputMessage("\nMy stats are: \nHealth: \(getHealth()) / \(getTotalHealth()) \nDamage: \(getMyBaseDamage()) / \(getTotalDamage()) \nStrength: \(getMyStr()) / \(getTotalStr()) \nDefense: \(getMyDef()) / \(getTotalDef()) \nCurrent Weight: \(backpack.getWeight()) / \(backpack.getWeightLimit()) \nMoney Held: \(getMoney())")
    }
    //lists the player's current stats as they change for the stats interface
    func getChangedStats()-> String {
        let message : String = ("My stats are: \nHealth: \(getHealth()) / \(getTotalHealth()) \nDamage: \(getMyBaseDamage()) / \(getTotalDamage()) \nStrength: \(getMyStr()) / \(getTotalStr()) \nDefense: \(getMyDef()) / \(getTotalDef()) \nCurrent Weight: \(backpack.getWeight()) / \(backpack.getWeightLimit())\nMoney Held: \(getMoney())")
        return message
    }
    //restores player health
    func restoreHealth() {
        setHealth(getTotalHealth() - (getTotalDef() * 2))
    }
        
    //gets player total health
    func getTotalHealth() -> integer_t{
        return totalHealth
    }
    //gets player total damage
    func getTotalDamage() -> integer_t{
        return totalDamage
    }
    //gets player total strength
    func getTotalStr() -> integer_t{
        return totalStrength
    }
    //gets player total defense
    func getTotalDef() -> integer_t{
        return totalDefense
    }
    //sets player total health
    func setTotalHealth(health : integer_t) {
        totalHealth = health
        
    }
    //sets player total damage
    func setTotalDamage(damage : integer_t) {
        totalDamage = damage
        
    }
    //sets player total strength
    func setTotalStrength(strength : integer_t){
        totalStrength = strength
        
    }
    //sets player total defense
    func setTotalDef(defense : integer_t) {
        totalDefense = defense
        
    }
    
    
    //sets player base damage
    func setMyBaseDamage(newDamage : integer_t) {
        playerBaseDmg = newDamage
        
    }
    //increases player base damage
    func increaseMyBaseDamage(amount : integer_t) {
        
        playerBaseDmg += amount
        setTotalDamage(getMyBaseDamage())
        changedMyStats()
    }
    //gets player base damage, calculated by strength and weapon damage
    func getMyBaseDamage() -> integer_t {
        if held != nil && held?.isWeapon() == true {
            if (held as! Weapon).isBroken() == false {
                setTotalDamage(playerBaseDmg + playerStrength + (held as! Weapon).getDamage())
                return playerBaseDmg + playerStrength + (held as! Weapon).getDamage()
            } else {
                setTotalDamage(playerBaseDmg + playerStrength)
                return playerBaseDmg + playerStrength
            }
            
        } else {
            setTotalDamage(playerBaseDmg + playerStrength)
            return playerBaseDmg + playerStrength
            
        }
    }
    
    
    //sets player strength
    func setMyStr(newStr : integer_t) {
        playerStrength = newStr
        
        
    }
    //gets player strength
    func getMyStr() -> integer_t {
        setTotalStrength(playerStrength)
        return playerStrength
    }
    //increases player strength
    func increaseStr(amount : integer_t) {
        
        playerStrength += amount
        let weightlimitamount : float_t = (3.0 * (float_t(amount)))
        
        
        backpack.increaseLimit(weightlimitamount)
        setTotalStrength(getMyStr())
        changedMyStats()
        
    }
    //decreases player strength
    func decreaseStr(amount : integer_t) {
        playerStrength -= amount
        changedMyStats()
    }
    //sets player defense
    func setMyDef(newDef : integer_t) {
        
        playerDefense = newDef
        
    }
    //gets player defense
    func getMyDef() -> integer_t {
        setTotalDef(playerDefense)
        return playerDefense
    }
    //increases player defense
    func increaseDef(amount : integer_t) {
        
        playerDefense += amount
        setTotalDef(getMyDef())
        setTotalHealth(getTotalHealth() + (2 * amount))
        changedMyStats()
        
    }
    //decreases player defense
    func decreaseDef(amount : integer_t) {
        playerDefense -= amount
        changedMyStats()
    }

    //sets player health
    func setHealth(newHealth : integer_t) {
        
        health = newHealth
        
    }
    //gets player health
    func getHealth() -> integer_t {
        
        return health + (playerDefense * 2)
    }
    //increases player health
    func increaseHealth(amount : integer_t) {
        setHealth(getTotalHealth() + amount - (getTotalDef() * 2))
        setTotalHealth(getHealth())
        changedMyStats()
    }
    
    
    
    //player health changed when attacked
    func damaged(amount : integer_t) -> Bool {
        if (getHealth() - amount) <= 0 {
            //dies
            setHealth(health - amount)
            changedMyStats()
            return true
        } else {
            setHealth(health - amount)
            changedMyStats()
            return false
        }

        
    }
    
    // increases player money
    func increaseMoney(amount : integer_t) {
        moneyPouch.addMoney(amount)
        changedMyStats() //new
    }
    
    //gets player money
    func getMoney() -> integer_t{
       return moneyPouch.getContents()
    }
    
    //sets player money
    func setMoney(money : integer_t) {
        moneyPouch.setContents(money)
    }
    
    //adds observer for player notifications
    func addNotifications() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(attackedBySomething(_ :)), name: "AttackedBySomething", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(NPCEntered(_:)), name: "NPCEnteredPlayerRoom", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(NPCLeft(_:)), name: "NPCLeftPlayerRoom", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(itemsDropped(_:)), name: "DroppedItems", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(enemyDied(_:)), name: "EnemyDied", object: nil)
    }
    
    //list money of player
    func listMoney() {
        outputMessage("\nYou are holding \(getMoney()) gold")
    }
    
    //prints items of the room when enemy killed
    @objc func itemsDropped(notification : NSNotification) {
        let thisRoom : Room = notification.object as! Room
        if currentRoom.getName() == thisRoom.getName() {
            outputMessage("\nYou gain a strength and defense level by defeating the enemy! The enemy dropped some items into the room, check out that sweet loot! You also find some gold pieces on the enemy, Nice!")
            outputMessage(currentRoom.getItemList())
            self.increaseMoney(10)
            self.increaseStr(1)
            self.increaseDef(1)
        }
    }
    
    //sends enemy died notification which adds loot to the room from enemy drops
    @objc func enemyDied(notification : NSNotification) {
        let enemy : Enemy = notification.object as! Enemy
        
        if currentRoom.hasThisEnemy(enemy.getName()) {
            currentRoom.addItem(enemy.getHeld()!)
            let tempDrops : [String : Item]? = enemy.drops.container
            if tempDrops != nil {
                for items in tempDrops!.values {
                    currentRoom.addItem(items)
                }
                NSNotificationCenter.defaultCenter().postNotificationName("DroppedItems", object: currentRoom)
            }
            currentRoom.removeEnemy(enemy.getName())
            
        }
        
    }
    
    
    //notification when player is attacked by something, take damage and tell what attacked you, and if you die or not
    @objc func attackedBySomething(notification : NSNotification) {
        let enemy : Enemy = notification.object as! Enemy
        let userInfo = notification.userInfo as! [String : Weapon]
        let enemyWeapon = userInfo["enemyWeapon"]
        let enemyDamage = enemy.getDamage()
        
        self.damaged(enemyDamage)
        if enemy.getHeld() != nil {
            outputMessage("\n\nYou were attacked by the \(enemy.getName()) it hit you for \(enemyDamage) damage with a \(enemy.getHeld()!.getName())")
        } else {
            outputMessage("\n\nYou were attacked by the \(enemy.getName()) it hit you for \(enemyDamage) damage unarmed")
        }
        if self.getHealth() <= 0 {
            
            
            var testDictionary : [String : String] = [String : String]()
            testDictionary["killedBy"] = enemy.getName()
                
            NSNotificationCenter.defaultCenter().postNotificationName("PlayerDied", object: self, userInfo: testDictionary)
            
        } else {
            outputMessage("\nYour Remaining Health: \(self.getHealth())\n")
        }
        
        
        
        
        
    }
    // attack method which attacks an enemy with whatever weapon the player is holding, if no weapon held you deal base damage, and if weapon breaks fight barehanded, posts notifications to enemy about how the player attacked them
    func attack() {
        if currentRoom.enemyList.isEmpty == false {
            if held != nil {
                if held?.isWeapon() == true {
                    let weapon : Weapon = (held as! Weapon)
                    if weapon.isBroken() == true {
                        warningMessage("\n Your weapon is broken, you will attack barehanded!")
                        var testDictionary : [String : String] = [String : String]()
                        testDictionary["playerWeapon"] = "bare fists"
                        
                        NSNotificationCenter.defaultCenter().postNotificationName("AttackedNoWeapon", object: self, userInfo: testDictionary)
                        
                    } else {
                        var testDictionary : [String : Weapon] = [String : Weapon]()
                        testDictionary["playerWeapon"] = (held as! Weapon)
                        
                        NSNotificationCenter.defaultCenter().postNotificationName("Attacked", object: self, userInfo: testDictionary)
                    }
                    
                } else {
                    warningMessage("\n \(held!.getName()) is not a weapon, you will attack barehanded!")
                    var testDictionary : [String : String] = [String : String]()
                    testDictionary["playerWeapon"] = "bare fists"
                    
                    NSNotificationCenter.defaultCenter().postNotificationName("AttackedNoWeapon", object: self, userInfo: testDictionary)
                }
            } else {
                warningMessage("\n You are not equipping anything, you will attack barehanded!")
                var testDictionary : [String : String] = [String : String]()
                testDictionary["playerWeapon"] = "bare fists"
                
                NSNotificationCenter.defaultCenter().postNotificationName("AttackedNoWeapon", object: self, userInfo: testDictionary)
                
            }
        } else {
            warningMessage("\nThere are no enemies in the room to attack")
        }
        
    }
    //posts notifications to blacksmith when the player tries to repair something, and the event is handled by the blacksmith, only sends if there is one in the room
    func repair(itemName : String) {
        if currentRoom.NPCList.isEmpty == false {
            if currentRoom.hasThisNPCOccupation("Blacksmith") == true {
                if self.isHoldingNamed(itemName) == true {
                    if held?.getName() == itemName {
                        if held!.isWeapon() {
                            var testDictionary : [String : Weapon] = [String : Weapon]()
                            testDictionary["playerWeapon"] = (held as! Weapon)
                            NSNotificationCenter.defaultCenter().postNotificationName("RespondToRepair", object: self, userInfo: testDictionary)
                            
                        } else {
                            warningMessage("\nItem is not repairable because it is not a weapon!")
                        }
                        
                        
                    } else {
                        let item : Item? = backpack.peekItem(itemName)
                        if item !=  nil {
                            if item!.isWeapon() {
                                var testDictionary : [String : Weapon] = [String : Weapon]()
                                testDictionary["playerWeapon"] = (item as! Weapon)
                                NSNotificationCenter.defaultCenter().postNotificationName("RespondToRepair", object: self, userInfo: testDictionary)
                                
                            } else {
                                warningMessage("\nItem is not repairable because it is not a weapon!")
                            }
                        } else {
                            warningMessage("\nYou are not holding \(itemName) in your backpack")
                        }
                        
                    }
                } else {
                    warningMessage("\nYou are not holding anything named \(itemName)")
                }
            } else {
                warningMessage("\nThere are no blacksmiths in the room to ask for repairs from")
            }
            
            
        } else {
            warningMessage("\nThere are no characters in the room")
        }
    }

    //searches the room to get original description
    func search() {
        
        var testDictionary : [String : Room] = [String : Room]()
        testDictionary["searchedRoom"] = currentRoom
        NSNotificationCenter.defaultCenter().postNotificationName("playerSearchRoom", object: self, userInfo: testDictionary)
    }
    
    //searches items in the room and does certain events based on correct search terms
    func searchSomething(thing : String) {
        
            
        if currentRoom.getName() == "cell" {
            if thing == "brick" || thing == "bricks" || thing == "wall" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
                    
                
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
        } else if currentRoom.getName() == "cell corridor" {
            if thing == "wall" || thing == "nail" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
        } else if currentRoom.getName() == "cellar" {
            if thing == "barrels" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
            
        } else if currentRoom.getName() == "sitting room" {
            if thing == "couch" || thing == "chairs" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
    
        } else if currentRoom.getName() == "training room" {
            if thing == "dummy" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
        

        } else if currentRoom.getName() == "armory" {
            if thing == "rack" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
        } else if currentRoom.getName() == "closet" {
            if thing == "wardrobe" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
        } else if currentRoom.getName() == "dining room" {
            if thing == "feast" || thing == "chicken" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
        } else if currentRoom.getName() == "kitchen" {
            if thing == "counter" || thing == "knives" || thing == "set" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }
            
        } else if currentRoom.getName() == "pantry" {
            if thing == "shelf" || thing == "shelves" {
                var testDictionary : [String : Room] = [String : Room]()
                testDictionary["searchedRoom"] = currentRoom
                NSNotificationCenter.defaultCenter().postNotificationName("playerSearchItemInRoom", object: self, userInfo: testDictionary)
            } else {
                outputMessage("\nYou find nothing of importance there")
            }

         
        } else {
            warningMessage("\nYou find nothing of importance there")
        }

        
        
    }
    
    
    //lists items player has in possession
    func listItems() {
        if held != nil {
            if backpack.isEmpty() == false {
                outputMessage("\n You are holding \n * \(held!.description()) \n \n Your \(backpack.getList())")
                listWeight()
            } else {
                outputMessage("\n You are holding \n * \(held!.description()) and there are no items in your backpack ")
                listWeight()
            }
            
            
        } else {
            if backpack.isEmpty() == false {
                outputMessage("\nYou aren't holding anything but Your \(backpack.getList())")
                listWeight()
            } else {
                warningMessage("\nYou aren't holding any items")
                listWeight()
            }
        }
        
    }
    
    //list items in current room
    func listRoomItems() {
        outputMessage(currentRoom.listItems())
    }
    
    //list characters in current room
    func listCharacters() {
        outputMessage(currentRoom.getNPCList())
    }
    //list enemy in current room
    func listEnemy() {
        outputMessage(currentRoom.getEnemyList())
    }
    //walk to a direction if there is a door there, and lets player through if they can progress that way
    func walkTo(direction : String) {
        let door : Door? = currentRoom.getExit(direction)
        if door != nil {
            if door!.isOpen() == true {
            
                roomStack.push(currentRoom)
                let nextRoom : Room? = door?.getRoom(currentRoom)
                if nextRoom != nil {
                    let lastRoom = self.currentRoom
                    NSNotificationCenter.defaultCenter().postNotificationName("playerWillEnterRoom", object: nextRoom)
                    self.currentRoom = nextRoom!
                    NSNotificationCenter.defaultCenter().postNotificationName("playerDidLeaveRoom", object: lastRoom)
                    self.outputMessage("\n\(nextRoom!.description())")
                    
                    
                    var testDictionary : [String : Room] = [String : Room]()
                    testDictionary["enteredRoom"] = currentRoom

                    
                    
                    NSNotificationCenter.defaultCenter().postNotificationName("playerDidEnterRoom", object: self, userInfo: testDictionary)
                } else {
                    self.errorMessage("\nThere is not a room to progress to")
                }
            } else {
                self.errorMessage("\nThe door on '\(direction)' is closed")
            }
        } else {
            self.errorMessage("\nThere is no door on '\(direction)'")
        }
    
    }
    
    //puts player in previous room
    func walkBack() {
        
        if roomStack.isEmpty() == true && currentRoom.getName() == "cell" {
            self.errorMessage("\nYou are at the beginning of the game, you can't go back!")
        } else if roomStack.isEmpty() {
            self.errorMessage("\nYou are at the beginning of the game, you can't go back!")
        } else {
            let nextRoom : Room? = roomStack.pop()
            self.currentRoom = nextRoom!
            var testDictionary : [String : Room] = [String : Room]()
            testDictionary["enteredRoom"] = currentRoom
            
            
            
            NSNotificationCenter.defaultCenter().postNotificationName("playerDidEnterRoom", object: self, userInfo: testDictionary)
            self.outputMessage("\n\(nextRoom!.description())")
            
        }
        
    }
    //stores item from hand to backpack if player had entered only store command
    func storeFromHand() {
        if held != nil {
            if (backpack.canHold(held!)) == false {
                    outputMessage("\nYou are too weak to carry the \(held!.getName()) in your backpack")
            } else {
                backpack.store(held!)
                outputMessage("\nYou put the \(held!.getName()) in your backpack, you are now empty handed")
                held = nil
                changedMyStats()
            }
        } else {
            warningMessage("\nThere is nothing in your hand to store!")
        }
    }
    //stores item in backpack from room if found
    func storeFromRoom(itemName : String) {
        let thisItem : Item? = currentRoom.removeItem(itemName)
        if thisItem != nil {
            if (backpack.canHold(thisItem!)) == false {
                outputMessage("\nYou are too weak to carry the \(thisItem!.getName())")
                currentRoom.addItem(thisItem!)
            } else {
                backpack.store(thisItem!)
                outputMessage("\nYou put the \(thisItem!.getName()) in your backpack")
                changedMyStats() //new
            }
        } else {
            outputMessage("\n There is no item named \(itemName) here")
        }
    }   
    
    
    //equips the item to the hand and stores the originally held item if there was one and it could be stored, if unable to be stored, the original item is dropped
    func retrieveFromBackpack(itemName : String) {
        
        if backpack.isEmpty() == false {
            if backpack.hasThisItem(itemName) {
                if held != nil {
                    if backpack.canHold(held!) == true {
                        backpack.store(held!)
                        outputMessage("\nYou stored the \(held!.getName()) in your backpack")
                        self.held = backpack.retrieve(itemName)
                        outputMessage(" and you are now holding the \(held!.getName())")
                        changedMyStats()
                    } else {
                        let temp : Item? = held
                        currentRoom.addItem(held!)
                        self.held = backpack.retrieve(itemName)
                        outputMessage("\nYou could not store the \(temp!.getName()) in your backpack because you are too weak, you dropped the \(temp!.getName()) but you equipped the \(held!.getName())")
                        changedMyStats()
                    }
                } else {
                    self.held = backpack.retrieve(itemName)
                    outputMessage("\nYou retrieved the \(held!.getName()) from your backpack, you are now holding the \(held!.getName())")
                    changedMyStats()
                }
            } else {
                warningMessage("\nThe \(itemName) is not in your backpack")
            }
        } else {
            warningMessage("\nYour backpack\(backpack.getName())is empty")
        }
        
    }
    
    
    //drops a specified item directly from backpack to current room
    func dropFromPack(itemName : String) {
        if backpack.isEmpty() == false {
            let thisItem : Item? = backpack.retrieve(itemName)
            if thisItem != nil {
                currentRoom.addItem(thisItem!)
                outputMessage("\nYou retrieved the \(thisItem!.getName()) from your backpack, and dropped the \(thisItem!.getName()) in the room")
                changedMyStats() //new
            } else {
                warningMessage("\nThe item \(itemName) could not be located")
            }
        } else {
            warningMessage("\nYour backpack \(backpack.getName()) is empty")
        }
    }
    //if user enters drop only, drops held item if there is one
    func dropFromHand() {
        if held != nil {
            currentRoom.addItem(held!)
            outputMessage("\nYou dropped the \(held!.getName()) in the room")
            held = nil
            changedMyStats()
            
        } else {
            warningMessage("\nYou aren't holding anything in your hands to drop!")
        }

    }
    //used to allow npc to remove a player's item from their hand
    func takeFromHand() -> Item? {
        if held != nil {
            let thisItem : Item? = held
            held = nil
            changedMyStats()
            return thisItem
            
        } else {
            return held
        }
    }
    //used to allow npc to remove a player's item from their backpack
    func takeFromPack(itemName : String) -> Item? {
        if  backpack.hasThisItem(itemName) == true {
            let thisItem : Item? = backpack.retrieve(itemName)
            changedMyStats() // new
            return thisItem
        } else {
            return nil
        }
    }
    //allows player to use lockpick on cell door
    func useItem(itemName : String, thing : String) {
        if held != nil {
            if held?.getName() == itemName {
                if currentRoom.getName() == "cell" {
                    if (thing == "door" || thing == "Door") && (itemName == "lockpick") {
                        
                        
                        self.unlock("north")
                        
                    } else if (thing == "door" || thing == "Door") {
                        warningMessage("\nTry using a different item on the door")
                    } else {
                        if itemName != "lockpick" {
                            warningMessage("\nTry using a different item")
                        } else {
                            outputMessage("\nTry using on a locked device")
                        }
                        
                    }
                } else {
                    warningMessage("\nUsing an item in this room serves no purpose")
                }
            } else {
                warningMessage("\nYou are not equipping any item named \(itemName)")
            }
        } else {
            warningMessage("\nYou are not equipping any item to use")
        }
    }
    //allows player to pickup an item from the room, and stores held item if can be stored
    func pickupItem(itemName : String) {
        if held == nil {
            if currentRoom.hasThisItem(itemName) == true {
                held = currentRoom.removeItem(itemName)
                
                    outputMessage("\nYou are now holding the \(held!.getName())")
                    changedMyStats()
                
                
            } else {
                warningMessage("\nThere is no item named \(itemName) in the room")
            }
        } else {
            if currentRoom.hasThisItem(itemName) == true {
                if held?.getName() == itemName {
                    warningMessage("\nYou are already holding this \(held!.getName()), you can't pick up what you are already holding")
                } else {
                    if backpack.canHold(held!) == true {
                        backpack.store(held!)
                        outputMessage("\nYou put the \(held!.getName()) in your backpack")
                        held = currentRoom.removeItem(itemName)
                        outputMessage(" and pickup the \(held!.getName())")
                        changedMyStats()
                    } else {
                        warningMessage("\nYou are not able to store your \(held!.getName()) because you are too weak, so you cannot pickup another item until you make room")
                    }
                }
            } else {
                warningMessage("\nThere is no item named \(itemName) in the room")
            }
            
            
        }
    }
    //allows player to give an item to an npc, if they desire that item
    func giveItem(characterName : String, itemName : String) {
        if currentRoom.NPCList.isEmpty == false {
            
            if currentRoom.hasThisNPC(characterName) == true {
                if held != nil {
                    if held?.getName() == itemName {
                        
                        var thisDictionary : [String : String] = [String : String]()
                        thisDictionary["givenItem"] = itemName
                        thisDictionary["desiredCharacter"] = characterName
                        thisDictionary["givenFrom"] = "hand"
                        NSNotificationCenter.defaultCenter().postNotificationName("GivenItem", object: self, userInfo: thisDictionary)
                        
                    } else {
                        if backpack.isEmpty() == false {
                            if backpack.hasThisItem(itemName) == true {
                                var thisDictionary : [String : String] = [String : String]()
                                thisDictionary["givenItem"] = itemName
                                thisDictionary["desiredCharacter"] = characterName
                                thisDictionary["givenFrom"] = "backpack"
                                NSNotificationCenter.defaultCenter().postNotificationName("GivenItem", object: self, userInfo: thisDictionary)
                                
                            } else {
                                warningMessage("\nYou are not holding any items named \(itemName)")
                            }
                        } else {
                            warningMessage("\nYou are not holding any items to give")
                        }
                    }
                } else {
                    if backpack.isEmpty() == false {
                        
                        if backpack.hasThisItem(itemName) == true {
                            
                            var thisDictionary : [String : String] = [String : String]()
                            thisDictionary["givenItem"] = itemName
                            thisDictionary["desiredCharacter"] = characterName
                            thisDictionary["givenFrom"] = "backpack"
                            NSNotificationCenter.defaultCenter().postNotificationName("GivenItem", object: self, userInfo: thisDictionary)
                            
                        } else {
                            warningMessage("\n You are not holding any items named \(itemName)")
                        }
                        
                    } else {
                        warningMessage("\n You are not holding any items to give!")
                    }
                }
                
            } else {
                warningMessage("\n There are no characters in the room named \(characterName)")
            }
            
        
        } else {
            warningMessage("\n There are no characters in the room to give items to")
        }
        
        
    }
    //checks if player can store an item, based on weight limit
    func canHold(item : Item) -> Bool {
        if backpack.canHold(item) {
            return true
        } else {
            return false
        }
    }
    //checks if player is holding an item
    func isHolding(item : Item?) -> Bool {
        if held != nil {
            if held === item {
                return true
            } else {
                if backpack.hasThisItem(item!.getName()) == true {
                    return true
                } else {
                    return false
                }
            }
            
        } else {
            if item != nil {
                if backpack.hasThisItem(item!.getName()) == true {
                    return true
                } else {
                    return false
                }
            } else {
                return false
            }
            
        }
    }
    //adds item given from npc to backpack
    func receiveItem(item : Item) {
        if backpack.canHold(item) {
            backpack.store(item)
        } else {
            warningMessage("\nYou cannot hold the \(item.getName()) because you are over the weight limit")
        }
    }
    
    //allows player to unlock a door if it is locked and they have the correct key
    func unlock(exitName : String) {
        let door : Door? = currentRoom.getExit(exitName)
        if door != nil {
            if door?.isLocked() == true {
                if door?.getOriginalKey() != nil {
                    if self.isHolding(door?.getOriginalKey()) == true {
                        door!.insertKey((door?.getOriginalKey())!)
                        door?.unlock()
                        outputMessage("\nYou unlocked the door at \(exitName)")
                        if currentRoom.getName() == "cell" {
                            if held?.getName() == "lockpick" {
                                takeFromHand()
                                outputMessage("\nAs you unlock the cell door, the lockpick breaks and is no longer able to be used")
                            } else {
                                takeFromPack("lockpick")
                                outputMessage("\nAs you unlock the cell door, the lockpick breaks and is no longer able to be used")
                            }
                        }
                    } else {
                        warningMessage("\nYou do not have the correct key")
                    }
                    
                } else {
                    warningMessage("\nYou do not have a key for this door")
                }

            } else {
                warningMessage("\nThe door is already unlocked")

            }
        } else {
            self.errorMessage("\nThere is no door on '\(exitName)'")
        }
    }
    //allows player to open a door if it is closed and if it is not locked, and if a door exists there
    func openDoor(exitName : String) {
        let door : Door? = currentRoom.getExit(exitName)
        
        if door != nil {
            if door!.isOpen() == true {
                self.warningMessage("\nThe exit \(exitName) is already open.\n")
            } else {
                
                door!.open()
                if door!.isOpen() {
                    outputMessage("\nYou opened the door at \(exitName).\n")
                } else {
                    if door!.isLocked() == true {
                        
                        if currentRoom.getName() == "foyer" {
                            warningMessage("\nThe door is barred from the other side, you didn't think it would be that easy to escape did you?")
                        } else {
                            warningMessage("\nThe door at \(exitName) is locked and cannot be opened.\n")
                        }
                    } else {
                        
                        warningMessage("\nThe door at \(exitName) could not be opened for an unknown reason.\n")
                    }
                }
            }
        } else {
            self.errorMessage("\nThere is no door on '\(exitName)'")
        }
    }
    //if user tries to open something other than a door
    func openSomething(thing : String) {
        if thing == "Door" || thing == "door" || thing == "cell" || thing == "Cell" {
            warningMessage("\nIf you are trying to open a door, type 'open door exitDirection', ex. open door north")
        } else {
            warningMessage("\nIf you are trying to open a door, type 'open door exitDirection', ex. open door north")
        }
        
        
    }
    //checks if player is holding an item by name
    func isHoldingNamed(itemName : String) -> Bool {
        if held != nil {
            if held?.getName() == itemName {
                return true
            } else {
                if backpack.hasThisItem(itemName) == true {
                    return true
                } else {
                    return false
                }
            }
        } else {
            if backpack.hasThisItem(itemName) == true {
                return true
            } else {
                return false
            }
        }
    }
    //allows player to ask an npc for a specified item
    func askForItem(itemName : String) {
        
        var itemDictionary : [String : String] = [String : String]()
        itemDictionary["desiredItem"] = itemName
        NSNotificationCenter.defaultCenter().postNotificationName("AskedForItem", object: self, userInfo: itemDictionary)
        
    }
    
    //allows player to talk to npcs
    func talkTo(name : String) {
        outputMessage(currentRoom.getResponseFrom(name))
    }
    //allows player to consume items if the item is consumable and sends a notification to the game world to handle the event
    func consume(itemName : String) {
        if isHoldingNamed(itemName) == true {
            if held?.getName() == itemName {
                if held?.isConsumable() == true {
                    if held?.isPotion() == true {
                        var testDictionary : [String : Potion] = [String : Potion]()
                        testDictionary["potion"] = (held as! Potion)
                        
                        NSNotificationCenter.defaultCenter().postNotificationName("playerConsumedSomething", object: self, userInfo: testDictionary)
                        
                    } else {
                        warningMessage("\n \(held!.getName()) is not a potion, you cannot consume that!")
                    }
                } else {
                    warningMessage("\n \(held!.getName()) is not consumable, you cannot consume that!")
                }
                
            } else {
                let thisItem : Item? = backpack.peekItem(itemName)
                if thisItem != nil {
                    if thisItem?.isConsumable() == true {
                        if thisItem?.isPotion() == true {
                            var testDictionary : [String : Potion] = [String : Potion]()
                            testDictionary["potion"] = (thisItem as! Potion)
                            
                            NSNotificationCenter.defaultCenter().postNotificationName("playerConsumedSomething", object: self, userInfo: testDictionary)
                            
                        } else {
                            warningMessage("\n \(thisItem!.getName()) is not a potion, you cannot consume that!")
                        }
                    } else {
                        warningMessage("\n \(thisItem!.getName()) is not consumable, you cannot consume that!")
                    }
                } else {
                    warningMessage("\nYou are not holding anything to consume!")
                }
            }
            
        } else {
            warningMessage("\nYou are not holding an item named \(itemName)")
        }
    }
    
    //allows player to buy an item from a merchant if there is one in the room, and the merchant has the item, sends the notification to merchant to handle event
    func buy(itemName : String) {
        if currentRoom.NPCList.isEmpty == false {
            if currentRoom.hasThisNPCOccupation("Merchant") {
                var itemDictionary : [String : String] = [String : String]()
                itemDictionary["desiredItem"] = itemName
                NSNotificationCenter.defaultCenter().postNotificationName("RespondToBuy", object: self, userInfo: itemDictionary)
            } else {
                warningMessage("\nThere are no merchants in the room to buy from")
            }
        } else {
            warningMessage("\nThere are no characters in the room to buy from")
        }
    }
    //allows the player to sell items to the merchant if there is one in the room, and sends notification to merchant to handle event
    func sell(itemName : String) {
        if currentRoom.NPCList.isEmpty == false {
            if currentRoom.hasThisNPCOccupation("Merchant") == true {
                if self.isHoldingNamed(itemName) == true {
                    if held?.getName() == itemName {
                        var itemDictionary : [String : String] = [String : String]()
                        itemDictionary["sellingItem"] = held?.getName()
                        itemDictionary["givenFrom"] = "hand"
                        NSNotificationCenter.defaultCenter().postNotificationName("RespondToSell", object: self, userInfo : itemDictionary)
                    } else {
                        let thisItem : Item = backpack.peekItem(itemName)!                        
                        var itemDictionary : [String : String] = [String : String]()
                        itemDictionary["sellingItem"] = thisItem.getName()
                        itemDictionary["givenFrom"] = "backpack"
                        NSNotificationCenter.defaultCenter().postNotificationName("RespondToSell", object: self, userInfo: itemDictionary)
                        
                    }
                    
                } else {
                    warningMessage("\nYou do not have any items named \(itemName) to sell")
                }
            } else {
                warningMessage("\nThere are no merchants in the room to sell to")
            }
            
        } else {
            warningMessage("\nThere are no characters in the room to sell to")
        }
        
    }
    
    //alerts player that an npc entered their current room
    @objc func NPCEntered(notification : NSNotification) {
        let theNpc : NonPlayableCharacter = notification.object as! NonPlayableCharacter
        let userInfo = notification.userInfo as! [String : Room]
        let theRoom : Room = userInfo["changedRoom"]!
        if theRoom === currentRoom {
            outputMessage("\n\n\(theNpc.getDescription()) entered your room")
        }
    }
    //alerts the player that an npc left their current room
    @objc func NPCLeft(notification : NSNotification) {
        let theNpc : NonPlayableCharacter = notification.object as! NonPlayableCharacter
        let userInfo = notification.userInfo as! [String : Room]
        let theRoom : Room = userInfo["changedRoom"]!
        if theRoom === currentRoom {
            outputMessage("\n\n\(theNpc.getDescription()) left your room")
        }

    }
    //this is the function used to send a notification to the game to update stats interface
    func changedMyStats() {
        NSNotificationCenter.defaultCenter().postNotificationName("PlayerChangedStats", object: self)
    }    
    
    //this allows a player to describe an item in the room
    func describe(itemName : String) {
        outputMessage("\n\(currentRoom.describe(itemName))\n")
    }
    //outputs text to main screen
    func outputMessage(message : String) {
        io.sendLine(message)
    }
    //outputs text and specified color to main screen
    func outputMessage(message : String, color : NSColor) {
        let lastColor : NSColor = io.currentColor
        io.currentColor = color
        self.outputMessage(message)
        io.currentColor = lastColor
    }
    //outputs error message to screen
    func errorMessage(message : String) {
        self.outputMessage(message, color: NSColor.redColor())
    }
    //outputs warning message to screen
    func warningMessage(message : String) {
        self.outputMessage(message, color: NSColor.orangeColor())
    }
    //outputs command message to screen
    func commandMessage(message : String) {
        self.outputMessage(message, color: NSColor.brownColor())
    }
}
