//
//  DropCommand.swift
//  StarterGame
//
//  Created by csu on 4/21/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation


// allows user to drop a specific item from their backpack if they enter a second word, otherwise drops from hand
class DropCommand: Command {
    
    override init() {
        super.init()
        self.name = "drop"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.dropFromPack(secondWord!)
            
        } else {
            player.dropFromHand()
        }
        return false
    }
}
