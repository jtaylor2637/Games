//
//  SellCommand.swift
//  Dungeon Dweller
//
//  Created by csu on 5/1/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//lets you sell items to the merchant if you have the item, you must specify the item name in the second word
class SellCommand : Command {
    override init() {
        super.init()
        self.name = "sell"
    }
    
    override func execute(player: Player) -> Bool {
        if hasSecondWord() {
            player.sell(secondWord!)
        } else {
            player.warningMessage("\nSell What?")
        }
        return false
    }
}