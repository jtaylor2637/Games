//
//  Enemy.swift
//  StarterGame
//
//  Created by csu on 4/22/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
// enemy class has a name, item drops in its backpack, health, attackdamage and a weapon it holds
class Enemy {
    var name : String
    var drops : Backpack = Backpack(name : "Enemy Backpack", weight : 0.0, value : 0, limit : 1000.0)
    var health : integer_t
    var attackDmg : integer_t
    var held: Weapon?
    init(name : String, health : integer_t, attackDmg : integer_t){
        self.name = name
        self.health = health
        self.attackDmg = attackDmg
        addNotifications()
    }
    //sets held item of enemy
    func setHeld(item : Weapon) {
        held = item
    }
    //gets held item of enemy
    func getHeld() -> Weapon? {
        return held
    }
    //gets name of enemy
    func getName() -> String {
        return name
    }
    //gets health of enemy
    func getHealth() -> integer_t {
        return health
    }
    //gets damage of enemy
    func getDamage() -> integer_t {
        if held != nil {
            return attackDmg + held!.getDamage()
        } else {
            return attackDmg
        }
        
    }
    //modifies enemy's health when they take damage from the player
    func damaged(amount : integer_t) -> Bool {
        if (self.getHealth() - amount) <= 0 {
            health -= amount
            return true
        } else {
            health -= amount
            return false
        }
        
    }
    //adds items to their backpack
    func addItem(thisItem : Item) {
        drops.store(thisItem)
        
    }
    
    //returns enemy description
    func getDescription() -> String {
        if held != nil {
            return ("A \(self.getName()) with a health of \(self.getHealth()) and an attack damage of \(self.getDamage()) and is armed with a \(held!.getName())")
        } else {
            return ("A \(self.getName()) with a health of \(self.getHealth()) and an attack damage of \(self.getDamage()) and unarmed")
        }
        
    }
    
    
    //adds observers for attack notifications
    func addNotifications() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(attacked(_ :)), name: "Attacked", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(attackedNoWeapon(_ :)), name: "AttackedNoWeapon", object: nil)
        
    }
    //this event happens when the player enters the room with an enemy, or if they do an action other than attack or consume
    func attackFirst() {
        var testDictionary : [String : Weapon] = [String : Weapon]()
        testDictionary["enemyWeapon"] = held
        
        NSNotificationCenter.defaultCenter().postNotificationName("AttackedBySomething", object: self, userInfo: testDictionary)
    }
    
    //notification handled event occurs when the player attacks the enemy, checks if enemy is in the room, then calculates the damage done to enemy, reduces weapon durability, and checks if you killed the enemy or if combat will continue
    @objc func attacked(notification : NSNotification){
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : Weapon]
        let playerWeapon : Weapon = userInfo["playerWeapon"]!
        let playerWeaponDamage = playerWeapon.getDamage()
        let playerTotalDamage = player.getMyBaseDamage()
        if player.currentRoom.hasThisEnemy(self.getName()) == true {
            self.damaged(playerTotalDamage)
            player.outputMessage("\nYou dealt \(playerTotalDamage) damage to the \(self.getName()) with your \(playerWeapon.getName())")
            if playerWeapon.getDurability() > 0 {
                playerWeapon.setDurability(playerWeapon.getDurability() - 0.5)
                if playerWeapon.getDurability() <= 0 {
                    playerWeapon.weaponBreaks()
                    player.warningMessage("\nYour weapon broke!")
                }
            }
            
            if self.getHealth() <= 0 {
                player.outputMessage("\nYou defeated the \(self.getName())")
                
                NSNotificationCenter.defaultCenter().postNotificationName("EnemyDied", object: self)
                
                
            } else {
                player.outputMessage("\nEnemy Remaining Health: \(self.getHealth())")
                var testDictionary : [String : Weapon] = [String : Weapon]()
                testDictionary["enemyWeapon"] = held
                
                NSNotificationCenter.defaultCenter().postNotificationName("AttackedBySomething", object: self, userInfo: testDictionary)
            }

        }
        
    }
    
    
    //notification handled event occurs when the player attacks the enemy barehanded, checks if enemy is in the room, then calculates the damage done to enemy, and checks if you killed the enemy or if combat will continue

    @objc func attackedNoWeapon(notification : NSNotification){
        let player : Player = notification.object as! Player
        let userInfo = notification.userInfo as! [String : String]
        let playerfists = userInfo["playerWeapon"]
        let playerDamage = player.getMyBaseDamage()
        if player.currentRoom.hasThisEnemy(self.getName()) == true {
            damaged(playerDamage)
            player.outputMessage("\nYou dealt \(playerDamage) damage to the \(self.getName()) with your fists")
            if self.getHealth() <= 0 {
                player.outputMessage("\nYou defeated the \(self.getName())")
                //var testDictionary : [String : String] = [String : String]()
                //testDictionary["EnemyKilled"] = self.getName()
                
                NSNotificationCenter.defaultCenter().postNotificationName("EnemyDied", object: self)
                
            } else {
                player.outputMessage("\nEnemy Remaining Health: \(self.getHealth())")
                var testDictionary : [String : Weapon] = [String : Weapon]()
                testDictionary["enemyWeapon"] = held
                
                NSNotificationCenter.defaultCenter().postNotificationName("AttackedBySomething", object: self, userInfo: testDictionary)
            }
        }
        
        
    }
    

}