//
//  Potion.swift
//  StarterGame
//
//  Created by csu on 4/27/16.
//  Copyright © 2016 JMK Productions. All rights reserved.
//

import Foundation
//potion class is a subclass of items that is consumable, is used to modify player stats as they consume them
class Potion : Item {
    
    var attribute : String // Healing, damage up, defense, strength, etc.
    var effect : integer_t // Amount of points of healing, damage, etc.
    
    init(name : String, weight : float_t, value : integer_t, attribute : String, effect : integer_t) {
        self.attribute = attribute
        self.effect = effect
        super.init(name : name, weight : weight, value : value)
    }
    //what the potion does
    func getAttribute() -> String {
        return attribute
    }
    //how much it does
    func getEffect() -> integer_t {
        return effect
    }
    
    override func isPotion() -> Bool {
        return true
    }
    
    override func isConsumable() -> Bool {
        return true
    }
    //various effects of potions
    override func description() -> String {
        if self.attribute == "healing" {
            return "\(super.description()) and restores your health"
        } else if self.attribute == "unknown" {
            return "\(super.description()) that does something"
        
        } else {
            return "\(super.description()) that adds \(self.getEffect()) points to your \(self.getAttribute())"
        }
        
    }
    
}